/* Shared helpers + landing board. No framework, no build step. Reads only prebuilt JSON. */
const App = (() => {
  let manifest = null;
  const fmt = {
    spread(x) { if (x == null) return "—"; if (x === 0) return "PK"; return (x > 0 ? "+" : "") + (Number.isInteger(x) ? x : x.toFixed(1)); },
    num(x, d = 1) { return x == null ? "—" : Number(x).toFixed(d); },
    pct(x, d = 0) { return x == null ? "—" : (100 * x).toFixed(d) + "%"; },
    kick(iso, tba) {
      if (!iso) return "TBA"; const d = new Date(iso);
      const t = d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
      return tba ? d.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" }) + " · time TBA" : t;
    },
    day(iso) { const d = new Date(iso); return d.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" }); },
    ago(iso) { if (!iso) return "—"; const h = (Date.now() - new Date(iso)) / 36e5; return h < 1 ? Math.round(h * 60) + " min ago" : h < 48 ? h.toFixed(1) + " h ago" : Math.round(h / 24) + " d ago"; },
  };
  async function loadManifest() {
    if (manifest) return manifest;
    const r = await fetch("json/manifest.json", { cache: "no-store" });
    if (!r.ok) throw new Error("manifest missing");
    manifest = await r.json(); return manifest;
  }
  async function loadJSON(path) {
    const m = await loadManifest();
    const r = await fetch(`${path}?v=${m.version}`);
    if (!r.ok) throw new Error(`missing ${path}`);
    return r.json();
  }
  function el(tag, attrs = {}, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) { if (k === "class") e.className = v; else if (k === "html") e.innerHTML = v; else if (v != null) e.setAttribute(k, v); }
    for (const k of kids.flat()) if (k != null) e.append(k.nodeType ? k : document.createTextNode(String(k)));
    return e;
  }
  return { fmt, loadManifest, loadJSON, el };
})();

/* ---------------- landing page ---------------- */
async function boardMain() {
  const { fmt, el } = App;
  const root = document.getElementById("board");
  const m = await App.loadManifest();
  const state = { league: localStorage.getItem("league") || (m.leagues.includes("CFB") ? "CFB" : m.leagues[0]), week: null, date: "all", conf: "all", ranked: false, fav: "all", status: "all" };
  const toolbar = document.getElementById("toolbar");
  function render() {
    state.week = state.week || m.current_week[state.league];
    App.loadJSON(m.slates[state.league][String(state.week)]).then(slate => paint(slate)).catch(() => { root.replaceChildren(el("div", { class: "empty" }, "This week's board hasn't been built yet. The site rebuilds every morning and hourly on game days.")); });
    buildToolbar();
  }
  function buildToolbar() {
    toolbar.replaceChildren();
    const seg = el("div", { class: "seg", role: "group", "aria-label": "League" });
    for (const lg of m.leagues) seg.append(el("button", { "aria-pressed": String(lg === state.league), onclick: null }, lg === "CFB" ? "College" : "NFL"));
    [...seg.children].forEach((b, i) => b.addEventListener("click", () => { state.league = m.leagues[i]; localStorage.setItem("league", state.league); state.week = null; state.date = "all"; state.conf = "all"; render(); }));
    toolbar.append(seg);
    const wk = el("select", { "aria-label": "Week" });
    for (const w of m.weeks[state.league]) wk.append(el("option", { value: w, selected: w === state.week ? "" : null }, `Week ${w}`));
    wk.addEventListener("change", () => { state.week = Number(wk.value); state.date = "all"; render(); });
    toolbar.append(el("label", {}, "Week ", wk));
    toolbar.append(el("label", {}, "Date ", el("select", { id: "f-date", "aria-label": "Date" })));
    toolbar.append(el("label", {}, "Conference ", el("select", { id: "f-conf", "aria-label": "Conference" })));
    const fav = el("select", { "aria-label": "Favorite or underdog" }, el("option", { value: "all" }, "Any side"), el("option", { value: "home" }, "Home favored"), el("option", { value: "away" }, "Away favored"));
    fav.value = state.fav; fav.addEventListener("change", () => { state.fav = fav.value; paint(window.__slate); });
    toolbar.append(el("label", {}, "Line ", fav));
    const st = el("select", { "aria-label": "Game status" }, el("option", { value: "all" }, "All games"), el("option", { value: "SCHEDULED" }, "Upcoming"), el("option", { value: "LOCKED" }, "In progress / locked"), el("option", { value: "FINAL" }, "Final"));
    st.value = state.status; st.addEventListener("change", () => { state.status = st.value; paint(window.__slate); });
    App.boardSplitMarket = App.boardSplitMarket || localStorage.getItem("board.splitMarket") || "spread";
    const segS = el("div", { class: "seg", role: "group", "aria-label": "Splits market" });
    for (const [k, lab] of [["spread", "Spread"], ["total", "Total"], ["moneyline", "ML"]]) segS.append(el("button", { "aria-pressed": String(k === App.boardSplitMarket) }, lab));
    [...segS.children].forEach((b, i) => b.addEventListener("click", () => {
      App.boardSplitMarket = ["spread", "total", "moneyline"][i];
      localStorage.setItem("board.splitMarket", App.boardSplitMarket);
      paint(window.__slate);
    }));
    toolbar.append(el("label", {}, "Splits ", segS));
    toolbar.append(el("label", {}, "Status ", st));
    const rk = el("input", { type: "checkbox" }); rk.checked = state.ranked; rk.addEventListener("change", () => { state.ranked = rk.checked; paint(window.__slate); });
    toolbar.append(el("label", {}, rk, state.league === "CFB" ? "Ranked teams only" : "Playoff-caliber (top-8 rated)"));
  }
  function fillSelect(id, values, current, label) {
    const s = document.getElementById(id); if (!s) return;
    s.replaceChildren(el("option", { value: "all" }, label));
    for (const v of values) s.append(el("option", { value: v, selected: v === current ? "" : null }, id === "f-date" ? fmt.day(v + "T12:00:00") : v));
    s.value = current;
  }
  function paint(slate) {
    if (!slate) return; window.__slate = slate;
    const games = slate.games;
    fillSelect("f-date", [...new Set(games.map(g => g.filters.date).filter(Boolean))].sort(), state.date, "All dates");
    document.getElementById("f-date").onchange = e => { state.date = e.target.value; paint(slate); };
    fillSelect("f-conf", [...new Set(games.flatMap(g => [g.filters.conf_home, g.filters.conf_away]).filter(Boolean))].sort(), state.conf, "All conferences");
    document.getElementById("f-conf").onchange = e => { state.conf = e.target.value; paint(slate); };
    const shown = games.filter(g => (state.date === "all" || g.filters.date === state.date) && (state.conf === "all" || g.filters.conf_home === state.conf || g.filters.conf_away === state.conf)
      && (!state.ranked || g.filters.ranked) && (state.fav === "all" || g.filters.favorite === state.fav) && (state.status === "all" || g.status === state.status));
    shown.sort(App.byPlayFirst);
    root.replaceChildren();
    if (!shown.length) { root.append(el("div", { class: "empty" }, "No games match these filters.")); return; }
    let lastDate = null;
    for (const g of shown) {
      if (g.filters.date !== lastDate) {
        lastDate = g.filters.date;
        root.append(el("div", { class: "date-head" }, lastDate ? fmt.day(lastDate + "T12:00:00") : "Date TBA", el("span", {}, `${shown.filter(x => x.filters.date === lastDate).length} games`)));
        root.append(el("div", { class: "col-head" }, el("div", {}, "Matchup"), el("div", {}, "Kickoff"), el("div", {}, "Spread (open)"), el("div", {}, "Total (open)"), el("div", {}, "Bets / Money" + (App.boardSplitMarket && App.boardSplitMarket !== "spread" ? " (" + (App.boardSplitMarket === "total" ? "total" : "ML") + ")" : "")), el("div", {}, "Model score"), el("div", {}, "Win probability"), el("div", {}, "Key edge")));
      }
      root.append(row(g));
    }
    document.getElementById("built").textContent = `Board generated ${fmt.ago(slate.generated_at)}. Lines are the latest snapshot per game; the model is ${games.find(g => g.model)?.model.model_version || "not yet fit"}.`;
  }
  function team(t, side) {
    return el("div", { class: "team" }, t.logo ? el("img", { src: t.logo, alt: "" }) : el("span", { style: "width:22px" }), t.rank ? el("span", { class: "rk" }, "#" + t.rank) : null,
      el("span", { class: "nm" }, t.is_fcs ? t.name + " (FCS)" : t.short || t.name), el("span", { class: "rec" }, t.record));
  }
  function row(g) {
    const mk = g.market || {}, md = g.model;
    const spreadCell = el("div", { class: "two mkt" },
      el("span", { class: "cell num" }, mk.spread_home == null ? "—" : fmt.spread(-mk.spread_home), el("span", { class: "sub" }, mk.spread_open_home == null ? "" : "open " + fmt.spread(-mk.spread_open_home))),
      el("span", { class: "cell num" }, mk.spread_home == null ? "—" : fmt.spread(mk.spread_home), el("span", { class: "sub" }, mk.spread_open_home == null ? "" : "open " + fmt.spread(mk.spread_open_home))));
    const totCell = el("div", { class: "cell num tot" }, mk.total == null ? "—" : fmt.num(mk.total), el("span", { class: "sub" }, mk.total_open == null ? "" : "open " + fmt.num(mk.total_open)));
    const modelCell = md ? el("div", { class: "two model" }, el("span", { class: "cell num" }, md.proj_away.toFixed(0)), el("span", { class: "cell num" }, md.proj_home.toFixed(0), el("span", { class: "sub" }, `spread ${fmt.spread(-md.proj_margin_home)} · total ${md.proj_total.toFixed(0)}`)))
      : el("div", { class: "cell model" }, el("span", { class: "badge warn" }, "No model yet"));
    const wp = md ? el("div", { class: "wp" }, el("span", { class: "num", style: "color:var(--away)" }, fmt.pct(1 - md.win_prob_home)), el("div", { class: "wpbar", title: `Home win probability ${fmt.pct(md.win_prob_home)}` }, el("i", { style: `width:${(100 * md.win_prob_home).toFixed(0)}%` })), el("span", { class: "num", style: "color:var(--home)" }, fmt.pct(md.win_prob_home)))
      : el("div", { class: "wp" }, "—");
    const sp = g.splits, ind = g.indicators || {};
    const splitCell = (() => {
      const mkey = App.boardSplitMarket || "spread";
      if (!sp) return el("div", { class: "cell splits mute" }, "no splits");
      const m = sp[mkey] || {};
      const t = m.ticket_pct_home, mo = m.money_pct_home;
      if (t == null && mo == null) return el("div", { class: "cell splits mute" }, "no splits");
      const box = el("div", { class: "cell splits" },
        App.splitsPair({ ticket: t, money: mo, market: mkey, homeAbbr: g.home.abbr, awayAbbr: g.away.abbr }));
      const disagree = t != null && mo != null && (t >= 0.5) !== (mo >= 0.5);
      const gap = t != null && mo != null ? Math.abs(t - mo) * 100 : 0;
      const marks = [];
      if (disagree) marks.push("money and tickets on opposite sides");
      else if (gap >= 12) marks.push(`${gap.toFixed(0)} point gap`);
      if ((ind.rlm || {})[mkey]) marks.push("RLM toward " + ind.rlm[mkey]);
      if ((ind.lopsided || {})[mkey]) marks.push("lopsided on " + ind.lopsided[mkey]);
      if ((ind.steam || []).includes(mkey)) marks.push("steam");
      if (marks.length) box.append(el("span", { class: "sp-flag" }, marks[0]));
      box.setAttribute("title", `${sp.book || "splits"} · ${sp.n} snapshot${sp.n === 1 ? "" : "s"}${marks.length ? " · " + marks.join(" · ") : ""}`);
      return box;
    })();
    const ke = g.key_edge ? el("div", { class: "edge-chip" }, el("span", { class: "badge " + g.key_edge.side }, g.key_edge.side === "home" ? g.home.abbr : g.away.abbr), " ", g.key_edge.label, " ", el("b", {}, Math.abs(g.key_edge.points).toFixed(1) + " pts"))
      : el("div", { class: "edge-chip" }, el("span", { class: "badge mute" }, "Edges not built"));
    const when = g.result ? el("div", { class: "when" }, el("span", { class: "final" }, `Final ${g.result.away}–${g.result.home}`), g.result.model_ats ? el("span", { class: "tv" }, `model vs spread: ${g.result.model_ats}`) : null)
      : el("div", { class: "when" }, fmt.kick(g.kickoff_utc, g.kickoff_is_tba), el("span", { class: "tv" }, [g.tv, g.venue && g.venue.city, g.neutral_site ? "neutral site" : null].filter(Boolean).join(" · ")));
    return el("a", { class: "row", href: `matchup.html?g=${g.game_id}` }, el("div", { class: "teams" }, team(g.away, "away"), team(g.home, "home")), when, spreadCell, totCell, splitCell, modelCell, wp, ke);
  }
  render();
}

/* Market indicator chips, shared by the odds tab and the matchup page. */
App.indicatorChips = function (state, market) {
  const el = App.el, out = [];
  if (!state) return out;
  const key = market === "moneyline" ? "spread" : (market || "spread");
  const act = (state.rlm_active || {})[key];
  const past = (state.rlm_ever || {})[key];
  if (act) {
    out.push(el("span", { class: "badge warn", title: `Moved ${Math.abs(act.move).toFixed(1)} toward ${act.toward} while ${(act.ticket_pct_majority * 100).toFixed(0)}% of tickets sat the other way` },
      `reverse line movement toward ${act.toward}`));
  } else if (past) {
    out.push(el("span", { class: "badge mute", title: past.detail || "" }, "reverse movement earlier, since rebounded"));
  }
  const lop = (state.lopsided || {})[key];
  if (lop) out.push(el("span", { class: "badge warn" }, `lopsided on ${lop}`));
  const steam = (state.events || []).filter(e => e.kind === "steam" && e.market === key);
  if (steam.length) {
    const last = steam[steam.length - 1];
    out.push(el("span", { class: "badge sig", title: last.detail }, `steam toward ${last.toward}`));
  }
  const kn = (state.events || []).filter(e => e.kind === "key_number" && e.market === key);
  if (kn.length) out.push(el("span", { class: "badge mute", title: kn[kn.length - 1].detail }, `crossed ${kn[kn.length - 1].key}`));
  const mv = (state.recent_move || {})[key];
  if (mv != null && Math.abs(mv) >= 0.5) {
    out.push(el("span", { class: "badge mute" }, `${Math.abs(mv).toFixed(1)} move in the last ${state.window_hours || 36}h`));
  }
  return out;
};

/* ------------------------------------------------------------------
   Market chart: the line for both sides over time, with event marks.
   Hover a dot for the number, the time, and the ticket/money split.
   Shared by the Odds tab and the matchup page.
   opts: { lineSeries, splitsSeries, events, market, homeAbbr, awayAbbr, book }
------------------------------------------------------------------- */
App.probToAmerican = function (p) {
  if (p == null || p <= 0 || p >= 1) return null;
  return p >= 0.5 ? -Math.round((100 * p) / (1 - p)) : Math.round((100 * (1 - p)) / p);
};

App.impliedProb = function (ml) {
  if (ml == null) return null;
  const n = Number(ml);
  if (!Number.isFinite(n) || n === 0) return null;
  return n > 0 ? 100 / (n + 100) : -n / (-n + 100);
};

/* Every snapshot behind the chart, as a table: the line, the price, and both splits, each stamped.
   Collapsed by default so it does not crowd the page. */
App.movementTable = function (series, market, homeAbbr, awayAbbr, book) {
  const rows = (series || []).filter(Boolean);
  const wrap = document.createElement("details");
  wrap.className = "move-tbl";
  const sum = document.createElement("summary");
  sum.textContent = `Every recorded move (${rows.length} snapshot${rows.length === 1 ? "" : "s"})`;
  wrap.appendChild(sum);
  if (!rows.length) {
    const p = document.createElement("p"); p.className = "sub-note";
    p.textContent = "No snapshots recorded for this game yet."; wrap.appendChild(p); return wrap;
  }
  const key = market === "moneyline" ? "moneyline" : market;
  const am = v => (v == null ? "—" : (Number(v) > 0 ? "+" : "") + Math.round(Number(v)));
  const pc = v => (v == null ? "—" : Math.round(v * 100) + "%");
  const lineOf = r => market === "total" ? (r.line_total == null ? "—" : Number(r.line_total).toFixed(1))
    : market === "moneyline" ? `${awayAbbr} ${am(r.ml_away)} / ${homeAbbr} ${am(r.ml_home)}`
    : (r.line_spread_home == null ? "—" : `${homeAbbr} ${Number(r.line_spread_home) > 0 ? "+" : ""}${Number(r.line_spread_home).toFixed(1)}`);
  const sideLab = market === "total" ? "Over" : homeAbbr;
  let html = `<table class="mvt"><thead><tr><th>When (local)</th><th>${market === "moneyline" ? "Price" : "Line"}</th>`
           + `<th>Bets ${sideLab}</th><th>Money ${sideLab}</th><th>Change</th></tr></thead><tbody>`;
  let prevLine = null;
  // newest first: the most recent state is what matters most
  for (const r of rows.slice().reverse()) {
    const when = new Date(r.t).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
    const cur = market === "total" ? r.line_total : market === "moneyline" ? r.ml_home : r.line_spread_home;
    let chg = "";
    if (prevLine != null && cur != null && Number(cur) !== Number(prevLine)) {
      const d = Number(prevLine) - Number(cur);      // prevLine is the NEWER row, so this is older -> newer
      chg = (d > 0 ? "+" : "") + (market === "moneyline" ? Math.round(-d) : (-d).toFixed(1));
    }
    prevLine = cur == null ? prevLine : cur;
    const tk = r[`${key}_ticket`], mn = r[`${key}_money`];
    const carried = r[`${key}_ticket_carried`] || r[`${key}_money_carried`];
    html += `<tr${carried ? ' class="carried"' : ""}><td>${when}</td><td class="num">${lineOf(r)}</td>`
         + `<td class="num">${pc(tk)}</td><td class="num">${pc(mn)}</td><td class="num chg">${chg}</td></tr>`;
  }
  html += "</tbody></table>";
  const box = document.createElement("div");
  box.className = "mvt-wrap";
  box.innerHTML = html;
  wrap.appendChild(box);
  const note = document.createElement("p");
  note.className = "sub-note";
  note.textContent = `Newest first. Percentages are the share on ${sideLab}; a shaded row means that figure was carried from an earlier pull because the source published nothing new.${book ? " Prices from " + book + "." : ""}`;
  wrap.appendChild(note);
  return wrap;
};

/* Timestamped log of what the market did, for the bullets under a chart. */
App.eventLog = function (events, market) {
  const key = market === "moneyline" ? "spread" : market;
  const evs = (events || []).filter(e => e.market === key);
  const ul = document.createElement("ul");
  ul.className = "market-notes evt";
  if (!evs.length) return ul;
  const head = document.createElement("li");
  head.innerHTML = "<b>What moved, and when</b>";
  ul.appendChild(head);
  const NAME = { rlm: "Reverse line movement", steam: "Steam (fast move)", lopsided: "Lopsided support",
                 money_divergence: "Big money", divergence: "Big money", key_number: "Key number crossed", line_move: "Line moved" };
  for (const e of evs.slice(-12)) {
    const li = document.createElement("li");
    const when = new Date(e.t).toLocaleString([], { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
    li.textContent = `${when} — ${NAME[e.kind] || e.kind.replace(/_/g, " ")}: ${e.detail}`;
    ul.appendChild(li);
  }
  return ul;
};

/* Upcoming and in-progress first, finished last; within a group, by kickoff. */
App.byPlayFirst = function (a, b) {
  const rank = s => (s === "FINAL" ? 2 : s === "LOCKED" ? 1 : 0);
  const d = rank(a.status) - rank(b.status);
  return d !== 0 ? d : String(a.kickoff_utc || "9999").localeCompare(String(b.kickoff_utc || "9999"));
};

/* In-game win probability: home side's chance of winning, play by play. Area above 50% is shaded
   in the home colour, below in the away colour, so who was in control reads at a glance. */
App.winProbChart = function (wp, homeAbbr, awayAbbr) {
  const pts = (wp && wp.points) || [];
  const wrap = document.createElement("div");
  wrap.className = "wpchart";
  if (pts.length < 3) {
    const p = document.createElement("p"); p.className = "sub-note";
    p.textContent = "Win probability appears once the game is under way.";
    wrap.appendChild(p); return wrap;
  }
  const W = 880, H = 300, L = 46, R = 58, T = 26, B = 34;
  const tMax = Math.max(3600, ...pts.map(p => p.t));
  const x = t => L + (t / tMax) * (W - L - R);
  const y = v => T + (1 - v) * (H - T - B);
  const mid = y(0.5);
  const o = [];
  // quarter bands and gridlines
  for (let q = 1; q <= 4; q++) {
    const x0 = x((q - 1) * 900), x1 = x(q * 900);
    if (q % 2 === 0) o.push(`<rect x="${x0.toFixed(1)}" y="${T}" width="${(x1 - x0).toFixed(1)}" height="${H - T - B}" fill="var(--chalk)" opacity=".55"/>`);
    o.push(`<text x="${((x0 + x1) / 2).toFixed(1)}" y="${H - 12}" text-anchor="middle" font-size="11" fill="var(--mute)">Q${q}</text>`);
  }
  if (tMax > 3600) o.push(`<text x="${x((3600 + tMax) / 2).toFixed(1)}" y="${H - 12}" text-anchor="middle" font-size="11" fill="var(--mute)">OT</text>`);
  for (const v of [0, 0.25, 0.5, 0.75, 1]) {
    o.push(`<line x1="${L}" y1="${y(v).toFixed(1)}" x2="${W - R}" y2="${y(v).toFixed(1)}" stroke="var(--rule)" ${v === 0.5 ? 'stroke-width="1.4"' : 'stroke-dasharray="3 4"'}/>`);
    o.push(`<text x="${L - 7}" y="${(y(v) + 4).toFixed(1)}" text-anchor="end" font-size="11" fill="var(--mute)">${Math.round(v * 100)}%</text>`);
  }
  // shaded areas: clip the curve against the 50% line
  const line = pts.map((p, i) => `${i ? "L" : "M"}${x(p.t).toFixed(1)},${y(p.wp).toFixed(1)}`).join(" ");
  const area = `${line} L${x(pts[pts.length - 1].t).toFixed(1)},${mid.toFixed(1)} L${x(pts[0].t).toFixed(1)},${mid.toFixed(1)} Z`;
  o.push(`<defs><clipPath id="wpAbove"><rect x="0" y="0" width="${W}" height="${mid.toFixed(1)}"/></clipPath>`
       + `<clipPath id="wpBelow"><rect x="0" y="${mid.toFixed(1)}" width="${W}" height="${H}"/></clipPath></defs>`);
  o.push(`<path d="${area}" fill="var(--home)" opacity=".18" clip-path="url(#wpAbove)"/>`);
  o.push(`<path d="${area}" fill="var(--away)" opacity=".18" clip-path="url(#wpBelow)"/>`);
  o.push(`<path d="${line}" fill="none" stroke="var(--ink)" stroke-width="2.2" stroke-linejoin="round"/>`);
  // team labels on the side each one owns
  o.push(`<text x="${W - R + 8}" y="${(T + 12).toFixed(1)}" font-size="12.5" font-weight="700" fill="var(--home)">${homeAbbr}</text>`);
  o.push(`<text x="${W - R + 8}" y="${(H - B - 4).toFixed(1)}" font-size="12.5" font-weight="700" fill="var(--away)">${awayAbbr}</text>`);
  // final marker
  const last = pts[pts.length - 1];
  o.push(`<circle cx="${x(last.t).toFixed(1)}" cy="${y(last.wp).toFixed(1)}" r="5.5" fill="var(--ink)" stroke="var(--paper)" stroke-width="2"/>`);
  const svgBox = document.createElement("div");
  svgBox.innerHTML = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Win probability through the game">${o.join("")}</svg>`;
  wrap.appendChild(svgBox);
  // tap or hover anywhere for the moment
  const ro = document.createElement("div");
  ro.className = "mchart-readout";
  ro.innerHTML = '<span class="ro-hint">Tap or hover the chart for the win probability at any moment.</span>';
  wrap.appendChild(ro);
  const clock = t => {
    if (t >= 3600) return "OT";
    const q = Math.min(4, Math.floor(t / 900) + 1), left = 900 - (t % 900);
    return `Q${q} ${Math.floor(left / 60)}:${String(Math.floor(left % 60)).padStart(2, "0")}`;
  };
  const show = clientX => {
    const svgEl = svgBox.querySelector && svgBox.querySelector("svg");
    if (!svgEl) return;
    const box = svgEl.getBoundingClientRect();
    const t = ((((clientX - box.left) / box.width) * W) - L) / (W - L - R) * tMax;
    let best = pts[0];
    for (const p of pts) if (Math.abs(p.t - t) < Math.abs(best.t - t)) best = p;
    const hw = Math.round(best.wp * 100);
    const lead = best.home_diff === 0 ? "tied" : best.home_diff > 0 ? `${homeAbbr} by ${best.home_diff}` : `${awayAbbr} by ${-best.home_diff}`;
    ro.innerHTML = `<span class="ro-when">${best.label === "final" ? "Final" : best.label === "kickoff" ? "Kickoff" : clock(best.t)}</span>`
      + `<span class="ro-line">${homeAbbr} ${hw}% · ${awayAbbr} ${100 - hw}%</span>`
      + `<span class="ro-split">${lead}</span>`;
  };
  const pick = ev => { const cx = ev.touches && ev.touches[0] ? ev.touches[0].clientX : ev.clientX; if (cx != null) show(cx); };
  svgBox.addEventListener("click", pick);
  svgBox.addEventListener("touchstart", pick, { passive: true });
  svgBox.addEventListener("mousemove", pick);
  return wrap;
};

App.marketChart = function (opts) {
  const el = App.el;
  const market = opts.market || "spread";
  const home = opts.homeAbbr || "HOME", away = opts.awayAbbr || "AWAY";
  const splits = (opts.splitsSeries || []).slice().sort((a, b) => new Date(a.t) - new Date(b.t));
  /* One book only. The splits source carries its own line at every snapshot, so the chart shows the
     number people were actually betting into. Falling back to the odds feed, a single book is picked
     rather than every book at once, which would look like the line was oscillating when it was not. */
  const fromSplits = splits.filter(p => p.line_spread_home != null || p.line_total != null || p.line_ml_home != null)
    .map(p => ({ t: p.t, book: p.book, spread_home: p.line_spread_home, total: p.line_total, ml_home: p.line_ml_home, ml_away: p.line_ml_away }));
  let line = fromSplits;
  let bookUsed = fromSplits.length ? (splits[0] || {}).book : null;
  if (!line.length) {
    const raw = (opts.lineSeries || []).filter(p => p && p.t);
    const counts = {};
    for (const p of raw) counts[p.book] = (counts[p.book] || 0) + 1;
    const prefer = ["draftkings", "consensus", "fanduel", "betmgm", "caesars", "espnbet", "bovada"];
    bookUsed = prefer.find(b => counts[b]) || Object.keys(counts).sort((a, b) => counts[b] - counts[a])[0] || null;
    line = raw.filter(p => p.book === bookUsed);
  }
  line = line.slice().sort((a, b) => new Date(a.t) - new Date(b.t));
  const events = (opts.events || []).filter(e => e.market === (market === "moneyline" ? "spread" : market));

  // the two plotted series, per market
  const spec = {
    spread: { a: p => (p.spread_home == null ? null : -p.spread_home), b: p => (p.spread_home == null ? null : p.spread_home),
              fmt: v => (v > 0 ? "+" : "") + v.toFixed(1), aLab: away, bLab: home, splitKey: "spread" },
    total: { a: p => (p.total == null ? null : p.total), b: () => null,
             fmt: v => v.toFixed(1), aLab: "total", bLab: null, splitKey: "total" },
    // American odds jump from -100 to +100 with nothing in between, so plotting the raw price on a
    // linear axis misrepresents the movement. Implied probability is continuous and comparable; the
    // price itself is kept in the readout.
    // Plotted on an implied-probability scale so the distances are meaningful -- American odds jump
    // from -100 to +100 with nothing in between -- but every number shown is the American price.
    moneyline: { a: p => App.impliedProb(p.ml_away), b: p => App.impliedProb(p.ml_home),
                 fmt: v => { const am = App.probToAmerican(v); return am == null ? "—" : (am > 0 ? "+" : "") + am; },
                 aLab: away, bLab: home, splitKey: "moneyline",
                 rawA: p => p.ml_away, rawB: p => p.ml_home },
  }[market];

  const pts = line.filter(p => spec.a(p) != null || (spec.b && spec.b(p) != null));
  if (pts.length < 1) return el("p", { class: "sub-note" }, "No line history recorded for this market yet.");

  // nearest ticket/money split at or before each point, for the hover
  const splitAt = (t) => {
    let found = null;
    for (const s of splits) { if (new Date(s.t) <= new Date(t)) found = s; else break; }
    return found;
  };
  // nearest plotted line point at or before a time, so the readout shows the number in force
  const lineAt = (t) => {
    let found = null;
    for (const q of pts) { if (new Date(q.t) <= new Date(t)) found = q; else break; }
    return found || pts[0];
  };
  const fmtAmerican = (v) => (v == null ? "—" : (Number(v) > 0 ? "+" : "") + Math.round(Number(v)));

  const pctTxt = (s, side) => {
    if (!s) return "no splits recorded";
    const tk = s[`${spec.splitKey}_ticket`], mn = s[`${spec.splitKey}_money`];
    if (tk == null && mn == null) return "no splits recorded";
    const v = (x, carried) => x == null ? "not published"
      : Math.round((side === "home" ? x : 1 - x) * 100) + "%" + (carried ? " (last published)" : "");
    return `Bets ${v(tk, s[`${spec.splitKey}_ticket_carried`])} · Money ${v(mn, s[`${spec.splitKey}_money_carried`])}`;
  };

  const W = 880, H = 320, L = 56, R = 20, T = 64, B = 40;   // T leaves a clear band for event labels
  const ts = pts.map(p => new Date(p.t).getTime());
  const t0 = Math.min(...ts), t1 = Math.max(...ts), span = Math.max(t1 - t0, 1);
  const x = t => L + ((t - t0) / span) * (W - L - R);
  const vals = [];
  for (const p of pts) { const a = spec.a(p), b = spec.b ? spec.b(p) : null; if (a != null) vals.push(a); if (b != null) vals.push(b); }
  let lo = Math.min(...vals), hi = Math.max(...vals);
  if (hi - lo < 1e-9) { lo -= 1; hi += 1; }
  const pad = (hi - lo) * 0.22;
  lo -= pad; hi += pad;
  const y = v => T + (1 - (v - lo) / (hi - lo)) * (H - T - B);

  const out = [];
  const ticks = 5;
  for (let i = 0; i < ticks; i++) {
    const v = lo + (hi - lo) * (i / (ticks - 1));
    out.push(`<line x1="${L}" y1="${y(v).toFixed(1)}" x2="${W - R}" y2="${y(v).toFixed(1)}" stroke="var(--rule)" opacity=".6"/>`);
    out.push(`<text x="${L - 8}" y="${(y(v) + 4).toFixed(1)}" text-anchor="end" font-size="11" fill="var(--mute)" class="num">${spec.fmt(v)}</text>`);
  }

  // event marks: dashed verticals with a label at the top
  const EV = { line_move: { c: "var(--mute)", lab: "" }, steam: { c: "var(--steam)", lab: "STEAM" },
               rlm: { c: "var(--rlm)", lab: "RLM" }, divergence: { c: "var(--split)", lab: "$" },
               key_number: { c: "var(--mute)", lab: "KEY" }, lopsided: { c: "var(--split)", lab: "LOP" } };
  const placed = [];               // [x, row] so clustered labels stack instead of overprinting
  for (const e of events) {
    const t = new Date(e.t).getTime();
    if (t < t0 || t > t1) continue;
    const cfg = EV[e.kind] || EV.line_move;
    const xx = x(t);
    const tip = `${new Date(e.t).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })} — ${e.kind.replace("_", " ")}: ${e.detail}`;
    out.push(`<line x1="${xx.toFixed(1)}" y1="${T - 6}" x2="${xx.toFixed(1)}" y2="${H - B}" stroke="${cfg.c}" stroke-width="${cfg.lab ? 1.6 : 1}" stroke-dasharray="4 4" opacity="${cfg.lab ? .95 : .55}"><title>${tip}</title></line>`);
    if (!cfg.lab) continue;
    let row = 0;
    while (placed.some(q => q[1] === row && Math.abs(q[0] - xx) < 44)) row++;
    row = Math.min(row, 2);
    placed.push([xx, row]);
    const ly = 16 + row * 15;
    const w = cfg.lab.length * 7 + 12;
    out.push(`<g><rect x="${(xx - w / 2).toFixed(1)}" y="${ly - 11}" width="${w}" height="15" rx="3" fill="${cfg.c}" opacity=".14"/>`
           + `<text x="${xx.toFixed(1)}" y="${ly}" text-anchor="middle" font-size="10.5" font-weight="700" fill="${cfg.c}">${cfg.lab}</text>`
           + `<title>${tip}</title></g>`);
  }

  // the two series
  const draw = (getter, colour, sideKey, label) => {
    const seg = pts.filter(p => getter(p) != null);
    if (!seg.length) return;
    out.push(`<path d="${seg.map((p, i) => `${i ? "L" : "M"}${x(new Date(p.t).getTime()).toFixed(1)},${y(getter(p)).toFixed(1)}`).join(" ")}" fill="none" stroke="${colour}" stroke-width="2"/>`);
    let prev = null;
    for (const p of seg) {
      const t = new Date(p.t).getTime();
      const sp = splitAt(p.t);
      const v = getter(p);
      const changed = prev != null && Math.abs(v - prev) > 1e-9;
      prev = v;
      const when = new Date(p.t).toLocaleString([], { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
      const tip = `${label} ${spec.fmt(v)}\n${when}\n${pctTxt(sp, sideKey)}${p.book ? "\nbook: " + p.book : ""}${changed ? "\n(number changed here)" : ""}`;
      const cx = x(t).toFixed(1), cy = y(v).toFixed(1);
      // generous transparent target first, so the dot is easy to hit on a phone
      out.push(`<g class="pt" data-t="${p.t}"><circle cx="${cx}" cy="${cy}" r="20" fill="transparent"/>`
             + (changed ? `<circle cx="${cx}" cy="${cy}" r="12" fill="${colour}" opacity=".18"/>` : "")
             + `<circle class="dot" cx="${cx}" cy="${cy}" r="${changed ? 8 : 6.5}" fill="${colour}" stroke="var(--paper)" stroke-width="2"/>`
             + `<title>${tip}</title></g>`);
    }
  };
  draw(spec.a, "var(--away)", "away", spec.aLab);
  if (spec.b) draw(spec.b, "var(--home)", "home", spec.bLab);

  // team labels, top left
  out.push(`<text x="${L}" y="${T - 12}" font-size="12.5" font-weight="700" fill="var(--away)">${spec.aLab}</text>`);
  if (spec.bLab) out.push(`<text x="${L + 8 + spec.aLab.length * 8}" y="${T - 12}" font-size="12.5" font-weight="700" fill="var(--home)">${spec.bLab}</text>`);
  const fmtT = t => new Date(t).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
  out.push(`<text x="${L}" y="${H - 10}" font-size="11" fill="var(--mute)">${fmtT(t0)}</text>`);
  out.push(`<text x="${W - R}" y="${H - 10}" text-anchor="end" font-size="11" fill="var(--mute)">${fmtT(t1)}</text>`);

  const wrap = el("div", { class: "mchart" });
  const svgBox = el("div", { html: `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Line movement with market events">${out.join("")}</svg>` });
  wrap.append(svgBox);
  const readout = el("div", { class: "mchart-readout" }, el("span", { class: "ro-hint" }, "Tap or click the chart for the detail at that moment."));
  wrap.append(readout);
  // Nearest-point selection on the whole plot: a touch never has to land on the dot itself.
  const picks = [];
  for (const p of splits.length ? splits : lines) {
    const t = new Date(p.t).getTime();
    if (t >= t0 && t <= t1) picks.push({ t, p });
  }
  const showAt = (clientX) => {
    const svgEl = svgBox.querySelector && svgBox.querySelector("svg");
    if (!svgEl || !picks.length) return;
    const box = svgEl.getBoundingClientRect();
    const vx = ((clientX - box.left) / box.width) * W;
    const tGuess = t0 + ((vx - L) / Math.max(1, W - L - R)) * span;
    let best = picks[0];
    for (const c of picks) if (Math.abs(c.t - tGuess) < Math.abs(best.t - tGuess)) best = c;
    const sp = splitAt(best.p.t) || best.p;
    const ln = lineAt ? lineAt(best.p.t) : best.p;
    const when = new Date(best.t).toLocaleString([], { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
    const aV = spec.a(ln || {}), bV = spec.b(ln || {});
    const priceTxt = spec.rawA
      ? ` · ${spec.aLab} ${fmtAmerican(spec.rawA(ln || {}))} / ${spec.bLab} ${fmtAmerican(spec.rawB(ln || {}))}`
      : "";
    readout.replaceChildren(
      el("span", { class: "ro-when" }, when),
      el("span", { class: "ro-line" }, spec.bLab
        ? `${spec.aLab} ${aV == null ? "—" : spec.fmt(aV)} · ${spec.bLab} ${bV == null ? "—" : spec.fmt(bV)}${priceTxt}`
        : `${bV == null ? (aV == null ? "—" : spec.fmt(aV)) : spec.fmt(bV)}`),
      el("span", { class: "ro-split" }, pctTxt(sp, "home")));
  };
  const onPick = ev => { const x = ev.touches && ev.touches[0] ? ev.touches[0].clientX : ev.clientX; if (x != null) showAt(x); };
  svgBox.addEventListener("click", onPick);
  svgBox.addEventListener("touchstart", onPick, { passive: true });
  svgBox.addEventListener("mousemove", onPick);
  wrap.append(el("p", { class: "mchart-key" },
    "Tap anywhere on the chart for the detail at that moment; larger dots are snapshots where the number changed. Dashed marks: ",
    el("b", { style: "color:var(--mute)" }, "grey"), " line move, ",
    el("b", { style: "color:var(--steam)" }, "STEAM"), " fast move, ",
    el("b", { style: "color:var(--rlm)" }, "RLM"), " moved against the crowd, ",
    el("b", { style: "color:var(--split)" }, "$"), " tickets and money split.",
    bookUsed ? ` Prices from ${bookUsed === "draftkings" ? "DraftKings" : bookUsed}.` : ""));
  return wrap;
};

/* Spread / Total / Moneyline toggle bound to a redraw callback. */
App.marketToggle = function (current, onChange) {
  const el = App.el;
  const seg = el("div", { class: "seg", role: "group", "aria-label": "Market" });
  const keys = ["spread", "total", "moneyline"];
  for (const [i, lab] of ["Spread", "Total", "Moneyline"].entries()) {
    seg.append(el("button", { "aria-pressed": String(keys[i] === current) }, lab));
  }
  [...seg.children].forEach((b, i) => b.addEventListener("click", () => onChange(keys[i])));
  return seg;
};

/* ------------------------------------------------------------------
   Ticket and money shares for BOTH sides of a market, one format used
   everywhere (board and Odds tab):

       Bets:   SEA = 65% / ARI = 35%
       Money:  SEA = 40% / ARI = 60%

   For totals the two sides are Over and Under. The majority side of each
   line is emphasised, and when bets and money favour opposite sides the
   emphasised figures turn red, because that disagreement is the signal.
   opts: { ticket, money, labelA, labelB, market, homeAbbr, awayAbbr }
------------------------------------------------------------------- */
App.splitsPair = function (opts) {
  const el = App.el;
  const t = opts.ticket == null ? null : Number(opts.ticket);
  const m = opts.money == null ? null : Number(opts.money);
  const labA = opts.labelA || (opts.market === "total" ? "Over" : opts.homeAbbr || "Home");
  const labB = opts.labelB || (opts.market === "total" ? "Under" : opts.awayAbbr || "Away");
  const disagree = t != null && m != null && (t >= 0.5) !== (m >= 0.5);
  const line = (label, v) => {
    if (v == null) return el("span", { class: "sp-line" }, el("span", { class: "k" }, label), el("span", { class: "sp-val" }, "—"));
    const a = Math.round(v * 100), b = 100 - a;
    return el("span", { class: "sp-line" }, el("span", { class: "k" }, label),
      el("span", { class: "sp-val" },
        el("span", { class: a >= b ? "hi" : "" }, `${labA} = ${a}%`),
        el("span", { class: "sep" }, " / "),
        el("span", { class: b > a ? "hi" : "" }, `${labB} = ${b}%`)));
  };
  return el("div", { class: "splits-pair" + (disagree ? " disagree" : "") }, line("Bets:", t), line("Money:", m));
};

/* Segmented controls set aria-pressed when they are built, but most click handlers only repaint the
   thing below them and never rebuild the toolbar -- so the highlight stayed on whatever was selected
   when the page loaded. One delegated listener keeps every .seg and .tabs group on every page in step,
   whether or not its own handler bothers to. */
document.addEventListener("click", (ev) => {
  const btn = ev.target && ev.target.closest ? ev.target.closest(".seg button, .tabs button") : null;
  if (!btn) return;
  const seg = btn.closest(".seg, .tabs");
  if (!seg) return;
  for (const sib of seg.querySelectorAll("button")) sib.setAttribute("aria-pressed", String(sib === btn));
}, true);
