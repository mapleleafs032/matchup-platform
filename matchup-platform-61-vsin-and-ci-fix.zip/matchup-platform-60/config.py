"""
Centralized configuration. Nothing tunable lives anywhere else.
Secrets are NOT here: they come from environment variables set by GitHub Actions secrets.
"""
from __future__ import annotations
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
TABLES = DATA / "tables"
RAW = DATA / "raw"
SNAPSHOTS = DATA / "snapshots"
SITE_DIR = ROOT / "site"
SITE_JSON = SITE_DIR / "json"

SEASON = 2026
LEAGUES = ("CFB", "NFL")
BACKTEST_SEASONS = [2021, 2022, 2023, 2024, 2025]   # post-COVID only; 2020 and earlier are hard-rejected
MIN_ALLOWED_SEASON = 2021

# ---- Provider keys (env only) -------------------------------------------------
CFBD_API_KEY = os.environ.get("CFBD_API_KEY", "").strip()
ODDS_API_KEY = os.environ.get("ODDS_API_KEY", "").strip()
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "").strip()

# ---- Odds routing (decision #2: free now, paid is a config flip) --------------
ODDS_PLAN = os.environ.get("ODDS_PLAN", "free")          # "free" | "paid"
ODDS_ROUTING = {
    "free": {"NFL": "odds_api", "CFB": "cfbd"},
    "paid": {"NFL": "odds_api", "CFB": "odds_api"},
}[ODDS_PLAN]
ODDS_API_REGIONS = "us"
ODDS_API_MARKETS = "h2h,spreads,totals"                  # 3 credits per call on The Odds API
ODDS_API_SPORT_KEYS = {"NFL": "americanfootball_nfl", "CFB": "americanfootball_ncaaf"}
ODDS_BOOK_PRIORITY = ["consensus", "draftkings", "fanduel", "betmgm", "caesars", "espnbet", "bovada"]

# ---- API budgets (§50). Hard stops; jobs skip rather than exceed. ------------
API_BUDGET = {
    "cfbd":     {"monthly": 1000 if os.environ.get("CFBD_TIER", "free") == "free" else 5000, "daily_soft": 250},
    "odds_api": {"monthly": 500 if ODDS_PLAN == "free" else 20000, "daily_soft": 25},
    "open_meteo": {"monthly": 200000, "daily_soft": 5000},
    "nflverse": {"monthly": 10**9, "daily_soft": 10**9},
    "espn":     {"monthly": 5000, "daily_soft": 200},
    "vsin":     {"monthly": 9000, "daily_soft": 260},   # 15-min cadence x 2 leagues is ~190/day
    "splits_feed": {"monthly": 10000, "daily_soft": 500},
}
BUDGET_DEGRADE_AT_PCT_REMAINING = 0.15   # below this, odds cadence halves automatically

# ---- Refresh cadences (hours). Game-day cadences handled by Apps Script timer. -
CADENCE = {
    "schedules_hours": 24,
    "odds_midweek_per_day": {"free": {"NFL": 2, "CFB": 2}, "paid": {"NFL": 6, "CFB": 6}}[ODDS_PLAN],
    "odds_gameday_hours_before_kick": {"free": 6, "paid": 8}[ODDS_PLAN],
}

# ---- Validation ranges (§44). Fractions 0..1 unless noted. -------------------
VALIDATION_RANGES = {
    "spread_home": (-60.0, 60.0),
    "total": (20.0, 110.0),
    "moneyline": (-10000, 10000),
    "points": (0, 120),
    "week_cfb": (1, 16),      # CFBD week numbering starts at 1 (no week 0)
    "week_nfl": (1, 22),
}

# ---- Season / week conventions -------------------------------------------------
NFL_GAME_TYPE_TO_SEASON_TYPE = {"REG": "REG", "WC": "POST", "DIV": "POST", "CON": "POST", "SB": "POST"}
CFBD_SEASON_TYPE = {"regular": "REG", "postseason": "POST", "both": None}
NFL_TIMEZONE = "America/New_York"   # nflverse gametime is Eastern

# ---- Game-level metric definitions (pipeline/metrics_game.py) ------------------
EXPLOSIVE_RUSH_YDS = 10
EXPLOSIVE_PASS_YDS = 20
# Garbage time. CFB: CFBD's published rule (lead >= threshold by period). NFL: pre-snap vegas win prob band.
CFB_GARBAGE_LEAD_BY_PERIOD = {2: 38, 3: 28, 4: 22}
NFL_GARBAGE_WP_BAND = (0.05, 0.95)
# Which upstream stats files to pull per league (nflverse release assets)
NFLVERSE_ASSETS = {
    "pbp": "https://github.com/nflverse/nflverse-data/releases/download/pbp/play_by_play_{season}.parquet",
    "ftn": "https://github.com/nflverse/nflverse-data/releases/download/ftn_charting/ftn_charting_{season}.parquet",
    "pfr_pass": "https://github.com/nflverse/nflverse-data/releases/download/pfr_advstats/advstats_week_pass_{season}.parquet",
    "pfr_def": "https://github.com/nflverse/nflverse-data/releases/download/pfr_advstats/advstats_week_def_{season}.parquet",
}
CFBD_STATS_CALLS_PER_WEEK = 5     # games/teams, stats/game/advanced, plays, drives, games/players

# ---- Analytics layer (pipeline/asof.py, pipeline/ratings.py) -----------------------
USE_GARBAGE_FILTERED = True          # which team_game_advanced variant feeds the model
FCS_GAME_WEIGHT = 0.5                # CFB: weight of FBS-vs-FCS games in windows and ridge fits
NIGHT_GAME_LOCAL_HOUR = 18           # local kickoff hour >= this -> NIGHT window
RIDGE_LAMBDA = {"CFB": 3.0, "NFL": 2.0}          # opponent-adjustment shrinkage; tuned in Phase 8 backtest
RECENCY_WEIGHTS = {"SEASON": 0.5, "LAST5": 0.3, "LAST3": 0.2}   # starting framework (§17); tuned in Phase 8
PRIOR_WEIGHT_BY_WEEK = {             # weight on previous-season OPP_ADJ values (§40); tuned in Phase 8
    "CFB": {1: 0.85, 2: 0.75, 3: 0.65, 4: 0.50, 5: 0.40, 6: 0.30, 7: 0.20, 8: 0.10, "default": 0.05},
    "NFL": {1: 0.70, 2: 0.55, 3: 0.40, 4: 0.30, 5: 0.20, 6: 0.10, "default": 0.05},
}
LOW_SAMPLE_GAMES = {"CFB": 4, "NFL": 4}
QUALITY_TARGET_GAMES = {"CFB": 6, "NFL": 5}

# ---- Roster engine (pipeline/roster_engine.py) ----------------------------------------
RP_POSITION_WEIGHTS = {"passing": 0.30, "ol": 0.20, "receiving": 0.15, "rushing": 0.10, "defense": 0.25}   # §12; tuned in Phase 8
OL_STARTS_FULL = {"NFL": 85, "CFB": 5}        # NFL: 17 games x 5 starters; CFB proxy: 5 retained OL = "full"
DEF_PRODUCTION_WEIGHTS = {"tackles": 1.0, "tfl": 2.0, "sacks": 3.0, "ints": 3.0, "pbu": 2.0, "qb_hurries": 1.5, "pressures": 1.5, "ff": 2.0}
RECRUIT_CLASS_WEIGHTS = {0: 0.15, 1: 0.35, 2: 0.30, 3: 0.20}   # years ago -> weight (current class matters least in-season)
CONTINUITY_WEIGHTS = {"CFB": {"rp_total": 0.45, "qb": 0.25, "hc": 0.15, "portal_churn": 0.15},
                      "NFL": {"rp_total": 0.50, "qb": 0.30, "hc": 0.20}}
PORTAL_CHURN_FULL = 25                         # incoming transfers at which churn penalty saturates
CFBD_ROSTER_CALLS_PER_SEASON = 8

# ---- Matchup engine (pipeline/matchup_engine.py). Weights = points per league-SD of edge_raw. PRIORS; fit in Phase 8. ----
MATCHUP_MODEL_VERSION = "MATCHUP_v0.7_prelim"
_W_NFL = {"OVERALL_OFF": 1.5, "OVERALL_DEF": 1.5, "PASS_OFF": 1.0, "PASS_DEF": 1.0, "RUSH_OFF": 0.5, "RUSH_DEF": 0.5, "QB": 1.5,
          "OFFENSIVE_LINE": 0.6, "DEFENSIVE_FRONT": 0.6, "EXPLOSIVE": 0.6, "SUCCESS": 0.5, "THIRD_DOWN": 0.3, "RED_ZONE": 0.3,
          "TURNOVER": 0.3, "SPECIAL_TEAMS": 0.3, "COACHING": 0.5, "TALENT": 0.0, "RETURNING_PROD": 0.5, "RECENT_FORM": 0.4,
          "SOS": 0.0, "HOME_FIELD": 1.0, "STYLE_FIT": 0.5, "INJURY": 1.0, "WEATHER": 0.3, "REST": 0.6}
MATCHUP_WEIGHTS_INIT = {"NFL": _W_NFL, "CFB": {**{k: v * 1.6 for k, v in _W_NFL.items()}, "TALENT": 1.0, "RETURNING_PROD": 0.8, "COACHING": 0.6, "HOME_FIELD": 1.0}}
HFA_DEFAULT_POINTS = {"NFL": 1.5, "CFB": 2.5}     # used only when no fitted ratings exist for the week
INJURY_POSITION_WEIGHTS = {"QB": 3.0, "OL": 0.6, "RB": 0.5, "WR": 0.6, "TE": 0.4, "EDGE": 0.7, "DL": 0.5, "LB": 0.4, "CB": 0.6, "S": 0.4, "K": 0.3, "P": 0.1, "LS": 0.05, "UNK": 0.2}
INJURY_SD_POINTS = 1.5            # injury burden units per league-SD (QB out alone = 2 SD)
TURNOVER_REGRESSION = 0.4         # turnover margin is mostly noise; shrink toward zero
WIND_PASS_THRESHOLD_MPH = 12
QB_MIN_CAREER_ATT = 80         # attempts in our 2021+ tables before career evidence is used for the QB index

# ---- Prediction model (pipeline/model.py, jobs/backtest.py, jobs/predict.py) ----------------
LEAGUE_AVG_TOTAL = {"NFL": 44.0, "CFB": 54.0}
TOTAL_FLOOR = 20.0
ATS_EDGE_THRESHOLD = {"NFL": 2.0, "CFB": 3.0}      # points of model-vs-market disagreement to count as an "edge" pick
CLOSING_BOOK_PRIORITY = ["nflverse_close", "consensus", "draftkings", "fanduel", "bovada", "betmgm", "espnbet"]
HFA_SHRINK_GAMES = {"NFL": 120, "CFB": 400}         # games of fit needed before the fitted HFA fully replaces the league prior

# ---- Market engine (pipeline/market_engine.py) -----------------------------------------
STEAM_WINDOW_HOURS = 3
STEAM_MIN_MOVE = 1.0            # points a number must move inside the steam window to count
MARKET_STATE_WINDOW_HOURS = 36  # how recent a move must be to describe the market RIGHT NOW
MIN_PROJ_SIDE = {"NFL": 7.0, "CFB": 10.0}   # projected total is raised so neither team is projected below this (blowouts run up the total)

# ---- AI analysis layer (pipeline/ai_agent.py, jobs/build_ai.py) -------------------------------
AI_MODEL_CANDIDATES = ["claude-sonnet-5", "claude-sonnet-4-6", "claude-haiku-4-5-20251001"]   # first that the account can use is kept
AI_MAX_GAMES_PER_RUN = 120          # cost guard per job run
AI_PROMPT_VERSION = "ai_v1.0"

# ---- Betting splits (ticket % / money %) ------------------------------------------------
# No free licensed feed exists. Input is either a manual paste (data/manual/splits_paste/) or a feed you license.
SPLITS_FEED = {"enabled": False, "provider": None, "base_url": None}
SPLITS_API_KEY = os.environ.get("SPLITS_API_KEY", "").strip()
SPLITS_BOOK_DEFAULT = "draftkings"
# VSiN publishes DraftKings ticket/handle splits on a public page. Polite cadence, identifying User-Agent,
# attribution shown in the app. Set enabled=False to stop collecting immediately.
# ESPN's core power-index endpoint returns the resume category as six UNLABELLED numbers. Once the
# position of strength of schedule is confirmed against a team whose rank is known, pin it here.
# Left as None, no strength-of-schedule value is stored at all -- a blank beats a wrong number.
# UNRESOLVED. resume[2] read 1,2,3... down a list requested sorted by SOS -- but a plain row index
# would look identical, so that observation cannot tell the two apart. Until the probe below
# distinguishes them, no strength-of-schedule value is stored and the row shows blank.
#   python -m pipeline.jobs.probe_espn_sos --season 2026

# ESPN's resume array comes back unlabelled. resume[2] read 1,2,3... down a list requested sorted by
# SOS -- but a plain row index looks identical, so that alone cannot identify the column. Until
# `python -m pipeline.jobs.probe_espn_sos` separates the two, nothing is stored and the row shows blank.
ESPN_SOS_RESUME_INDEX = None        # set per-run by the cross-sort check below; never trusted statically
# The column we believe holds the SOS rank. It is only used if a second pull under a different sort
# shows the value travelling with the team rather than following the row position.
ESPN_SOS_CANDIDATE_INDEX = 2
ESPN_SOS_SORTED_REQUEST = True

# Paste files are re-read on every run. Once their games have kicked off every row is rejected as
# locked, so old files add nothing but noise -- they were still being reprocessed hourly weeks later.
SPLITS_PASTE_MAX_AGE_DAYS = 4
# The board carries every game on the slate. Parsing only a handful of team rows means the page changed
# and the parser is reading almost none of it -- which looked like a successful run for four days.
SPLITS_MIN_TEAM_ROWS = {"NFL": 16, "CFB": 40}

MARKET_FROM_VSIN = True    # VSiN carries the DraftKings line with the splits: one source, one timestamp
VSIN = {"enabled": True, "attribution": "Betting splits: DraftKings action via VSiN (data.vsin.com)"}

# ---- VSiN subscription (paid) -----------------------------------------------------------
# The PUBLIC splits page carries only the current day's card behind a paywall teaser, so midweek it
# shows one or two games out of a full slate. Measured 2026-10-05: NFL 2 team rows, week view 0,
# linetracker 0, every page carrying inline-lock / template-shown markup. A VSiN Pro subscription
# includes the DraftKings and Circa splits, so the session below is the subscriber's own.
# Credentials are env-only and never written to the repo. Either:
#   VSIN_COOKIE                  the Cookie request header copied from a signed-in browser tab
#   VSIN_EMAIL + VSIN_PASSWORD   log in through the account form on each run
VSIN_COOKIE = os.environ.get("VSIN_COOKIE", "").strip()
VSIN_EMAIL = os.environ.get("VSIN_EMAIL", "").strip()
VSIN_PASSWORD = os.environ.get("VSIN_PASSWORD", "")
VSIN_AUTH = {
    "login_url": "https://vsin.com/my-account/",
    "verify_url": "https://data.vsin.com/betting-splits/",
    # When credentials ARE configured but the session comes back anonymous, stop rather than write a
    # partial slate. An expired cookie that silently collects one game of sixteen is the exact failure
    # this whole integration exists to end.
    "fail_when_not_signed_in": True,
}
# Pages to try for a FULL WEEK of games, best first. The day-only splits page is the last resort.
# Each entry: (label, url template, query params). {sport} -> NFL/CFB, {path} -> nfl/college-football.
VSIN_SCOPE_PAGES = [
    ("splits week",  "https://data.vsin.com/betting-splits/", {"sport": "{sport}", "source": "DK", "view": "week"}),
    ("splits day",   "https://data.vsin.com/betting-splits/", {"sport": "{sport}", "source": "DK"}),
]
# The linetracker header observed on 2026-10-05 listed Circa, Boomers, BetMGM and Caesars. Signed in,
# that page is the first multi-book pricing this platform has had: real line shopping and a closing
# number that is not one book's opinion. The parser is written from a signed-in sample, not guessed --
# run `--explain linetracker` once the secret is set and the shape gets pinned here.
VSIN_LINETRACKER = {
    "enabled": False,          # flipped on once the signed-in page shape is confirmed
    "url": "https://data.vsin.com/{path}/vegas-odds-linetracker/",
    "books": ["circa", "boomers", "betmgm", "caesars", "draftkings"],
}
# Splits sources VSiN publishes. DK is the default; Circa is sharp money and worth its own series.
VSIN_SPLIT_SOURCES = ["DK"]    # add "CIRCA" once the signed-in page confirms the parameter name

# ---- Closing-line value ----------------------------------------------------------------
# The last number ON RECORD is not automatically the closing number. During the splits outage the
# newest snapshot for a Saturday game was four days old; scoring against that measured the gap in
# collection, not the market. A number observed further out than this is reported and NOT scored.
CLV_CLOSE_WINDOW_MIN = 240
# Which book's close counts when several are on record. Circa first: it posts early, moves on sharp
# money and its close is the industry's reference price.
CLV_BOOK_PRIORITY = ["circa", "consensus", "draftkings", "betmgm", "caesars", "boomers", "fanduel", "westgate"]
SPLITS_PERIODS = ("FULL", "1H")
# Divergence: ticket share minus money share, in percentage points, at which the two disagree enough to note.
SPLITS_DIVERGENCE_PTS = 12
# Reverse line movement: the line moved toward the side with the MINORITY of tickets by at least this much.
RLM_MIN_MOVE = 0.5
RLM_MIN_TICKET_PCT = 0.60

# ---- Picks engine (pipeline/picks_engine.py) --------------------------------------------
# Minimum model-vs-market disagreement before a play is even a candidate.
PICK_MIN_EDGE = {"NFL": {"SPREAD": 1.5, "TOTAL": 2.0, "MONEYLINE_EV": 0.04},
                 "CFB": {"SPREAD": 2.5, "TOTAL": 3.0, "MONEYLINE_EV": 0.05}}
PICK_EDGE_CAP = {"SPREAD": 7.0, "TOTAL": 8.0, "MONEYLINE": 7.0}   # beyond this, more disagreement is usually a data problem
PICK_EV_TO_POINTS = 20.0            # converts moneyline expected value into the same scale as point edges
PICK_SIGNAL = {"money_divergence": 0.12}
PICK_SIGNAL_BONUS = {"rlm_agrees": 0.8, "money_agrees": 0.5, "key_number": 0.4, "line_agrees": 0.3}
# How the score is split. Early in a season the market knows more than a model running on a prior, so
# market behaviour carries at least half the reason a play is ranked where it is.
PICK_WEIGHTS = {"model": 0.5, "market": 0.5}
PICK_SCORE_SCALE = 10.0            # both components are normalised 0..1, then scaled to this
# Market components, each 0..1 before weighting. They sum above 1 on purpose: a play showing several
# independent signals saturates, which is the intent.
PICK_MARKET_COMPONENTS = {"steam": 0.40, "rlm_agrees": 0.35, "money_agrees": 0.30,
                          "line_agrees": 0.15, "key_number": 0.05}
# A move hours before kickoff says more than one from Monday, so signals are aged.
PICK_SIGNAL_RECENCY = [(6, 1.00), (24, 0.90), (72, 0.70), (9999, 0.50)]   # (hours before kickoff, weight)
# A play must have a statistical edge AND market evidence supporting that side.
# The spread is the primary market. A moneyline play is only worth making on a short favourite, where
# laying the points and taking the win outright are close in value and the price is not prohibitive;
# on bigger favourites the moneyline pays too little, and on underdogs it is a different bet entirely.
PICK_MONEYLINE_ONLY_SHORT_FAVOURITE = True
PICK_MONEYLINE_SPREAD_RANGE = (1.0, 3.5)    # the favourite must be laying between these many points

PICK_REQUIRE_MARKET_CONFIRMATION = True
PICK_MIN_CONFIRMATIONS = 1
# Only market BEHAVIOUR confirms a side. A favourable key number is a positional bonus, not confirmation.
PICK_CONFIRMING_SIGNALS = ("rlm_agrees", "money_agrees", "line_agrees")
# The market actively fading our side vetoes the play regardless of how large the model edge is.
PICK_VETO_ON_OPPOSITION = True
PICK_OPPOSE_MONEY_GAP = 0.15        # our side's money share trails its ticket share by this much
PICK_OPPOSE_LINE_MOVE = 1.0         # the number moved this far away from our side
# Floors on the 0-10 combined scale. A play needs real strength on BOTH halves to reach A+: with the
# market weighted at 0.5, a perfect model edge and no market support tops out at 5.0.
PICK_TIERS = {"A+": 6.0, "A": 4.5, "B": 3.0}
# The top tier means strong on BOTH halves. Without these floors a barely-qualifying edge with every
# market signal firing would reach A+, and so would a huge edge with token support -- neither is what
# "edge AND market support" means.
PICK_TOP_TIER_FLOORS = {"model": 0.40, "market": 0.50}
# Bands used to MEASURE how disagreement relates to winning. Tiers are then named by measured performance,
# so A+ means "the band that historically won most often", not "the biggest disagreement".
PICK_SCORE_BANDS = [1.0, 1.8, 2.5, 3.2, 4.0, 5.0, float("inf")]
PICK_MIN_CALIBRATION_N = 40         # below this many graded historical plays, a band reports "unmeasured"
# Ranking bands by observed hit rate fits noise: with ~100 plays a band's interval spans 20 points.
# Tiers therefore order by SCORE (intuitive and stable) and each play carries the measured record of the
# band it falls in. The only band-level action taken is on bands that are measurably LOSING.
PICK_EXCLUDE_MEASURABLY_LOSING = True   # drop plays whose band's whole 95% interval sits below break-even
PICK_MAX_PER_WEEK = 150

# ---- Gates: a statistical edge alone is NOT a play. Each gate can veto, and every veto is recorded. ----
PICK_GATES = {
    "require_splits": True,          # no ticket/money data means the play cannot be confirmed
    # A statistical edge is not a play on its own: the market must actively support the same side.
    "require_confirmation": True,
    "min_confirmations": 1,
    # Only market BEHAVIOUR confirms a side. A favourable key number is positional, not confirmation.
    "confirming_signals": ("money_agrees", "rlm_agrees", "line_agrees", "steam"),
    "veto_rlm": True,                # reverse line movement kills the play...
    "rlm_only_against_us": True,     # ...but only when it runs AGAINST us; toward us it is confirmation
    "lopsided_threshold": 0.70,      # a side holding >= this share of BOTH tickets and money is lopsided
    "veto_lopsided": True,           # avoid markets with lopsided support, either direction
    "max_line_move_against": 1.0,    # points the number may move against our side before we pass
    "require_marquee": True,         # college only: stay with games that get real betting volume
}
# "High volume" proxy for college football, since no volume figure is published.
PICK_MARQUEE = {
    "power_conferences": ["SEC", "Big Ten", "ACC", "Big 12", "Pac-12"],
    "independents_ok": ["FBS Independents"],
    "require_moneyline_posted": True,   # books price a moneyline on games they take real action on
    "min_rating_pct": 0.35,             # both teams at least this percentile in our own ratings
    "ranked_always_qualifies": True,
}

# ---- Storage --------------------------------------------------------------------
APPEND_ONLY_PATHS = [   # CI immutability check (Phase 3 §3) — relative to repo root
    "data/tables/market/snapshots",
    "data/tables/market/splits",
    "data/tables/model/predictions",
    "data/tables/model/pregame_final_flags.csv",
    "data/tables/model/ai_analyses",
    "data/tables/model/ai_analyses_index.csv",
    "data/tables/model/picks_evaluation",
    "data/tables/model/pregame_snapshots_index.csv",
    "data/tables/model/model_evaluation",
    "data/tables/results",
    "data/tables/roster/injuries",
    "data/tables/context/weather_snapshots",
    "data/tables/ops/job_log.csv",
    "data/tables/ops/validation_log.csv",
    "data/tables/ops/raw_responses.csv",
    "data/snapshots",
]

# Raw payload archiving: keyed/quota APIs are archived (small JSON, needed for rebuilds and disputes).
# nflverse bulk files are NOT archived (1 MB+ per pull, publicly versioned upstream); the index row still records the sha.
RAW_ARCHIVE_PROVIDERS = {"cfbd", "odds_api", "espn", "open_meteo"}

PIPELINE_VERSION = "ingest_v0.1"

# ---- Forward tests (pipeline/cohorts.py) ---------------------------------------------------
# A forward test only means something if the hypothesis is fixed BEFORE the games it is judged on are
# played. These are registered once and not edited after the fact; to test something new, add an entry.
#
# Each cohort is rebuilt from stored data exactly as the backtest measured it: the final pregame
# projection against the closing number, with no market filter. It is graded whether or not a pick was
# made, so the market-confirmation gate cannot quietly shrink or bias the test.
#
# decide_at: the verdict is withheld until this many graded games. Checking every day and stopping the
#            moment the numbers look good inflates false positives ("optional stopping"), so the running
#            record is shown but the verdict waits.
# alpha:     the significance bar for that single pre-registered decision, corrected across all primary
#            cohorts registered here.
COHORTS = [
    {"id": "cfb_totals_edge4", "league": "CFB", "market": "TOTAL", "min_edge": 4.0, "primary": True,
     "label": "College totals, model edge 4+ pts",
     "hypothesis": "When the model's projected total differs from the closing total by 4 or more points, "
                   "its over/under side wins more often than the 52.4% break-even.",
     "evidence": "Backtest 2022-24: 54.7% on 918. Untouched 2025: 52.7% on 188. Not significant on its own.",
     "registered": "2026-09-21", "decide_at": 200, "alpha": 0.05},
    {"id": "cfb_totals_edge5", "league": "CFB", "market": "TOTAL", "min_edge": 5.0, "primary": False,
     "label": "College totals, model edge 5+ pts",
     "hypothesis": "The same effect, stronger at a higher threshold. Nested inside the 4+ cohort, so it is "
                   "tracked for the dose-response shape, not as a separate test.",
     "evidence": "Backtest 2022-24: 55.1% on 709. Untouched 2025: 53.0% on 117.",
     "registered": "2026-09-21", "decide_at": 150, "alpha": 0.05},
]
