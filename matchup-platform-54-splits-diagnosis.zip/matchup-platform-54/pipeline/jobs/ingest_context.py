"""
python -m pipeline.jobs.ingest_context --league NFL --what rosters injuries qbr
python -m pipeline.jobs.ingest_context --league CFB --what rosters rankings coaches venues
python -m pipeline.jobs.ingest_context --league BOTH --what weather manual        (weather needs venues first)
python -m pipeline.jobs.ingest_context --league BOTH --what all

Storage (Phase 3 layout):
  ref/players/{league}.parquet, ref/player_aliases.parquet, ref/venues.parquet         REBUILDABLE
  roster/roster_snapshots/{league}/{season}/W{ww}.parquet, roster/depth_charts/...     APPEND by week (rewritten per week)
  roster/injuries/{league}/{season}.csv                                                 APPEND-ONLY
  roster/coaches.csv (provider + manual rows)                                          APPEND-ONLY
  context/rankings/{season}.parquet                                                    REBUILDABLE per week
  context/weather_snapshots/{league}/{season}/W{ww}.csv                                APPEND-ONLY
  ops/manual_lists.csv, ops/kickoff_overrides.csv                                      from data/manual/
"""
from __future__ import annotations
import argparse
import glob
import sys
from datetime import datetime, timezone

import pandas as pd

import config
from pipeline import ids, storage
from pipeline.log import JobRun, ValidationLog
from providers import cfbd_context, nflverse_context, open_meteo
from providers.base import RequestManager, BudgetExceeded, ProviderError

REF = config.TABLES / "ref"
ROSTER = config.TABLES / "roster"
CONTEXT = config.TABLES / "context"
MANUAL = config.DATA / "manual"


def _now():
    return datetime.now(timezone.utc)


def _merge_by_key(path, new: pd.DataFrame, keys: list[str]):
    cur = storage.read_table(path)
    if not cur.empty and not new.empty:
        k_new = new[keys].astype(str).agg("|".join, axis=1)
        k_cur = cur[keys].astype(str).agg("|".join, axis=1)
        cur = cur[~k_cur.isin(set(k_new))]
        new = pd.concat([cur, new], ignore_index=True)
    if not new.empty:
        storage.write_parquet(path, new)
    return len(new)


def _current_week(games: pd.DataFrame) -> int:
    sched = games[(games.status == "SCHEDULED") & games.kickoff_utc.notna()]
    return int(sched.week.min()) if not sched.empty else int(games.week.max())


# ---- NFL --------------------------------------------------------------------------
def nfl(what: set[str], season: int, job: JobRun):
    rm = RequestManager("nflverse", job.job_run_id)
    resolver = ids.AliasResolver.load()
    games = storage.read_table(storage.games_path("NFL", season))
    if "players" in what or "rosters" in what or "qbr" in what:
        raw = nflverse_context.fetch_asset(rm, "players")
        players, aliases = nflverse_context.normalize_players(raw)
        storage.write_parquet(REF / "players" / "NFL.parquet", players)
        cur = storage.read_table(REF / "player_aliases.parquet")
        cur = cur[~cur.player_id.str.startswith("NFL_P_")] if not cur.empty else cur
        storage.write_parquet(REF / "player_aliases.parquet", pd.concat([cur, aliases], ignore_index=True))
        job.rows_written += len(players)
        print(f"NFL players: {len(players)}")
    if "rosters" in what:
        raw = nflverse_context.fetch_asset(rm, "rosters", season)
        if raw is not None:
            prior_files = sorted(glob.glob(str(ROSTER / "roster_snapshots" / "NFL" / str(season - 1) / "*.parquet")))
            prior = pd.read_parquet(prior_files[-1]) if prior_files else None
            ros = nflverse_context.normalize_rosters(raw, season, resolver, prior)
            for wk, part in ros.groupby("week"):
                storage.write_parquet(ROSTER / "roster_snapshots" / "NFL" / str(season) / f"W{int(wk):02d}.parquet", part)
            job.rows_written += len(ros)
            print(f"NFL rosters: {len(ros)} rows, weeks {sorted(ros.week.unique().tolist())}")
        raw = nflverse_context.fetch_asset(rm, "depth", season)
        if raw is not None and not games.empty:
            dc = nflverse_context.normalize_depth_charts(raw, season, games, resolver)
            for wk, part in dc.groupby("week"):
                storage.write_parquet(ROSTER / "depth_charts" / "NFL" / str(season) / f"W{int(wk):02d}.parquet", part)
            job.rows_written += len(dc)
            print(f"NFL depth charts: {len(dc)} rows, weeks {sorted(dc.week.unique().tolist())}")
    if "injuries" in what:
        raw = nflverse_context.fetch_asset(rm, "injuries", season)
        if raw is None:
            print(f"NFL injuries {season}: not published yet")
        else:
            inj = nflverse_context.normalize_injuries(raw, season, games, resolver)
            n = storage.append_csv(ROSTER / "injuries" / "NFL" / f"{season}.csv", inj, ["injury_row_id"], on_duplicate="skip")
            job.rows_written += n
            print(f"NFL injuries: {n} new rows ({len(inj)} in file)")
    if "coaches" in what:
        from providers import nflverse as nv
        raw = nv.fetch_schedules(rm)
        d = raw[(raw.season == season) & (raw.game_type == "REG")]
        pairs = pd.concat([d[["home_team", "home_coach"]].rename(columns={"home_team": "team", "home_coach": "coach"}),
                           d[["away_team", "away_coach"]].rename(columns={"away_team": "team", "away_coach": "coach"})]).dropna()
        rows = []
        for team, g in pairs.groupby("team"):
            tid = resolver.resolve("nflverse", alias=team)
            for coach, n in g.coach.value_counts().items():     # a mid-season change yields two rows; manual dates refine
                cid = str(coach).lower().replace(" ", "_").replace(".", "")
                rows.append({"team_id": tid, "season": season, "role": "HC", "coach_name": coach, "coach_id": cid, "effective_from": f"{season}-01-01",
                             "effective_to": None, "is_first_season_in_role": None, "source": "nflverse", "entered_by": None,
                             "retrieved_at": raw.attrs["retrieved_at"].isoformat(), "games": int(n), "wins": None, "losses": None,
                             "needs_manual_dates": len(g.coach.unique()) > 1, "coach_row_id": f"{tid}_{season}_HC_{cid}"})
        if rows:
            n = storage.append_csv(ROSTER / "coaches.csv", pd.DataFrame(rows), ["coach_row_id"], on_duplicate="skip")
            job.rows_written += n
            print(f"NFL head coaches {season}: {n} new rows")
    if "qbr" in what:
        raw = nflverse_context.fetch_asset(rm, "qbr")
        pa = storage.read_table(REF / "player_aliases.parquet")
        q = nflverse_context.normalize_qbr(raw, season, games, pa)
        path = config.TABLES / "stats" / "player_game_stats" / "NFL" / f"{season}.parquet"
        pgs = storage.read_table(path)
        if not pgs.empty and not q.empty:
            pgs = pgs.drop(columns=["qbr"]).merge(q, on=["game_id", "player_id"], how="left")
            storage.write_parquet(path, pgs)
            print(f"NFL QBR: {int(pgs.qbr.notna().sum())} of {len(pgs)} QB game rows now carry QBR")
    job.api_calls = rm.calls_this_run


    if "fpi" in what:
        from pipeline.log import ValidationLog as _VL
        _vl = _VL(job.job_run_id, "espn_fpi")
        _unmatched: set = set()
        espn_fpi_ingest("NFL", season, job, _vl, ids.AliasResolver.load(), _unmatched)
        for _u in sorted(_unmatched):
            _vl.warn("ALIAS_UNMATCHED", _u, "espn_team", _u, "known NFL team")
        _vl.flush()          # without this a failure here left no trace anywhere


# ---- CFB --------------------------------------------------------------------------
def espn_fpi_ingest(league: str, season: int, job: JobRun, vlog: ValidationLog,
                    resolver: ids.AliasResolver, unmatched: set) -> None:
    """ESPN power-index ranks (strength of schedule, FPI, offence, defence, special teams).

    Shared by both leagues: the college and NFL pages are the same product on different
    endpoints, with a different sort key for the strength-of-schedule column."""
    from providers import espn_fpi
    from providers.base import RequestManager as _RM, ProviderError as _PE
    erm = _RM("espn", job.job_run_id)
    try:
        payload, which, fnotes = espn_fpi.fetch(erm, season, league)
        for fn in fnotes:
            print(f'    endpoint note: {fn}')
    except _PE as e:
        vlog.warn("PROVIDER_FAIL", "espn_fpi", "", str(e)[:160], "200")
        print(f"ESPN FPI {season}: unavailable ({str(e)[:120]})")
        payload = None
    # Resolve the unlabelled column properly: a second pull under a different sort tells a real
    # statistic (travels with the team) from a row index (follows the position).
    verified_idx = None
    if payload is not None and config.ESPN_SOS_CANDIDATE_INDEX is not None:
        # Reversing the sort we already know is accepted is enough: a row index renumbers down the
        # reversed list, a real rank stays with its team. Other keys are tried only as a fallback.
        for alt in ("resume.avgsosrank:desc", "fpi.fpi:asc", None):
            try:
                second = espn_fpi.fetch_sorted(erm, season, alt, league)
            except Exception as e:
                print(f"    second pull ({alt or 'unsorted'}) rejected: {str(e)[:100]}")
                continue
            ok2, why2 = espn_fpi.verify_across_sorts(payload, second, config.ESPN_SOS_CANDIDATE_INDEX)
            print(f"    cross-sort check ({alt or 'unsorted'}): {why2}")
            if ok2:
                verified_idx = config.ESPN_SOS_CANDIDATE_INDEX
                break
            if "same order" not in why2:
                break          # a definite answer, even a negative one: stop asking
    if payload is not None:
        _teams = storage.read_table(REF / "teams.parquet")
        _added, _unmapped = espn_fpi.seed_aliases(payload, league, resolver, _teams)
        ident = espn_fpi.identify_columns(payload, league)
        inv = ident.get("inventory") or {}
        print("    categories in this response: " + (", ".join(f"{k} ({v})" for k, v in inv.items()) or "none"))
        if ident.get("available"):
            print("    column identification against ESPN's published values:")
            for _col, _d in sorted((ident.get("columns") or {}).items(), key=lambda kv: (kv[1]["category"], kv[1]["index"])):
                _mark = "OK " if _d["confident"] else "?? "
                _kind = "value" if _d["is_value"] else "rank"
                print(f"      {_mark}{_col:14} -> {_d['category']}[{_d['index']}] ({_kind}, {_d['matched']}/{_d['of']})")
            missing = [c for c in ("fpi", "sos", "offense", "defense", "special_teams") if c not in (ident.get("columns") or {})]
            if missing:
                print(f"      not found anywhere in the response: {', '.join(missing)}")
        else:
            print(f"    column identification unavailable: {ident.get('note')}")
        if _added:
            print(f"    learned {_added} ESPN team alias(es)")
        if _unmapped:
            print(f"    {len(_unmapped)} ESPN name(s) still unmapped: {', '.join(_unmapped[:12])}"
                  + (" ..." if len(_unmapped) > 12 else ""))
    import providers.espn_fpi as _ef
    _prev = config.ESPN_SOS_RESUME_INDEX
    config.ESPN_SOS_RESUME_INDEX = verified_idx
    if payload is not None:
        f, notes = espn_fpi.normalize(payload, season, resolver, __import__("pandas").Timestamp.now(tz="UTC"), unmatched, league)
        for n in notes:
            vlog.warn("SHAPE", "espn_fpi", "", n[:200], "strength of schedule")
            print(f"    {n}")
        if f.empty or f.sos_rank_espn.isna().all():
            print(f"ESPN FPI {season}: no usable strength-of-schedule values. Response shape:")
            print("    " + espn_fpi.describe(payload))
            rv = espn_fpi.resume_values(payload)[:6]
            if rv:
                print("    resume values per team (to pin the column):")
                for nm, vals in rv:
                    print(f"      {nm}: {vals}")
        else:
            # per league: one file per season would have NFL and CFB overwriting each other, leaving
            # whichever ran last and silently dropping the other league back to our own ranks
            _merge_by_key(CONTEXT / "espn_fpi" / league / f"{season}.parquet", f, ["team_id", "season"])
            # print a couple of teams so the rank columns can be checked against the page directly
            show = f.dropna(subset=["power_rank_espn"]).head(3)
            for _, rr in show.iterrows():
                print(f"      {rr.espn_team}: SOS {rr.sos_rank_espn}, Power {rr.power_rank_espn}, "
                      f"Off {rr.offense_rank_espn}, Def {rr.defense_rank_espn}, ST {rr.special_teams_rank_espn}")
            job.rows_written += len(f)
            print(f"ESPN FPI {season} (via {which}): {len(f)} teams, {int(f.sos_rank_espn.notna().sum())} with a strength-of-schedule rank")
    config.ESPN_SOS_RESUME_INDEX = _prev
    job.api_calls += erm.calls_this_run


def cfb(what: set[str], season: int, job: JobRun, vlog: ValidationLog):
    rm = RequestManager("cfbd", job.job_run_id)
    resolver = ids.AliasResolver.load()
    games = storage.read_table(storage.games_path("CFB", season))
    week = _current_week(games) if not games.empty else 1
    unmatched: set[str] = set()
    if "rosters" in what:
        try:
            res = cfbd_context.fetch_roster(rm, season)
            payloads = [res.payload]
            ts = res.retrieved_at
        except ProviderError as e:
            if "400" not in str(e):
                raise
            teams = storage.read_table(REF / "teams.parquet"); teams = teams[teams.league == "CFB"]
            payloads, ts = [], _now()
            for _, t in teams.iterrows():
                payloads.append(cfbd_context.fetch_roster(rm, season, t.school_or_city).payload)
        prior_files = sorted(glob.glob(str(ROSTER / "roster_snapshots" / "CFB" / str(season - 1) / "*.parquet")))
        prior = pd.read_parquet(prior_files[-1]) if prior_files else None
        ros_all, pl_all = [], []
        for pl in payloads:
            ros, players = cfbd_context.normalize_roster(pl, season, week, resolver, ts, prior, unmatched)
            ros_all.append(ros); pl_all.append(players)
        ros = pd.concat(ros_all, ignore_index=True); players = pd.concat(pl_all, ignore_index=True)
        storage.write_parquet(ROSTER / "roster_snapshots" / "CFB" / str(season) / f"W{week:02d}.parquet", ros)
        _merge_by_key(REF / "players" / "CFB.parquet", players.drop_duplicates("player_id"), ["player_id"])
        job.rows_written += len(ros)
        print(f"CFB rosters: {len(ros)} players on {ros.team_id.nunique()} teams as of week {week}")
    if "rankings" in what:
        res = cfbd_context.fetch_rankings(rm, season, week)
        rk = cfbd_context.normalize_rankings(res.payload, resolver, res.retrieved_at, unmatched)
        if not rk.empty:
            _merge_by_key(CONTEXT / "rankings" / f"{season}.parquet", rk, ["season", "week", "poll", "team_id"])
            job.rows_written += len(rk)
        print(f"CFB rankings week {week}: {len(rk)} rows, polls {sorted(rk.poll.unique().tolist()) if not rk.empty else []}")
    if "coaches" in what:
        res = cfbd_context.fetch_coaches(rm, season)
        co = cfbd_context.normalize_coaches(res.payload, season, resolver, res.retrieved_at, unmatched)
        if not co.empty:
            co["coach_row_id"] = co.team_id + "_" + co.season.astype(str) + "_" + co.role + "_" + co.coach_id
            n = storage.append_csv(ROSTER / "coaches.csv", co, ["coach_row_id"], on_duplicate="skip")
            job.rows_written += n
            print(f"CFB head coaches {season}: {n} new rows; {int(co.needs_manual_dates.sum())} teams with mid-season change need manual dates")
    if "fpi" in what:
        espn_fpi_ingest("CFB", season, job, vlog, resolver, unmatched)
    if "venues" in what:
        res = cfbd_context.fetch_venues(rm)
        v = cfbd_context.normalize_venues(res.payload, res.retrieved_at)
        _merge_by_key(REF / "venues.parquet", v, ["venue_id"])
        job.rows_written += len(v)
        print(f"CFB venues: {len(v)}")
    for u in sorted(unmatched):
        vlog.warn("ALIAS_UNMATCHED", u, "team", u, "team_aliases row (non-FBS teams expected)")
    job.api_calls = rm.calls_this_run


# ---- shared -------------------------------------------------------------------------
def load_manual(job: JobRun, vlog: ValidationLog):
    teams = storage.read_table(REF / "teams.parquet")
    known = set(teams.team_id) if not teams.empty else set()
    # NFL venues (static)
    nv = pd.read_csv(MANUAL / "nfl_venues.csv")
    nv["retrieved_at"] = _now().isoformat()
    for c in ("elevation_m", "capacity", "surface"):
        nv[c] = None
    _merge_by_key(REF / "venues.parquet", nv, ["venue_id"])
    # coordinators
    co = pd.read_csv(MANUAL / "coaches_manual.csv")
    co = co[co.coach_name.notna() & (co.coach_name.astype(str).str.strip() != "")]
    rows = []
    for _, r in co.iterrows():
        if r.team_id not in known:
            vlog.reject("IDENTITY", f"coaches_manual:{r.team_id}", "team_id", r.team_id, "known team_id"); continue
        if r.role not in ("OC", "DC", "HC"):
            vlog.reject("RANGE", f"coaches_manual:{r.team_id}", "role", r.role, "OC|DC|HC"); continue
        cid = str(r.coach_name).lower().replace(" ", "_").replace(".", "")
        rows.append({"team_id": r.team_id, "season": int(r.season), "role": r.role, "coach_name": r.coach_name, "coach_id": cid,
                     "effective_from": r.effective_from, "effective_to": r.effective_to if pd.notna(r.effective_to) else None,
                     "is_first_season_in_role": None, "source": "manual", "entered_by": r.entered_by, "retrieved_at": _now().isoformat(),
                     "coach_row_id": f"{r.team_id}_{int(r.season)}_{r.role}_{cid}"})
    if rows:
        job.rows_written += storage.append_csv(ROSTER / "coaches.csv", pd.DataFrame(rows), ["coach_row_id"], on_duplicate="skip")
    # rivalries
    rv = pd.read_csv(MANUAL / "rivalries.csv")
    rows = []
    for _, r in rv.iterrows():
        if r.team_a not in known or r.team_b not in known:
            vlog.warn("IDENTITY", f"rivalries:{r.team_a}-{r.team_b}", "team", f"{r.team_a},{r.team_b}", "known team_ids"); continue
        rows.append({"list_name": "RIVALRY", "league": r.league, "key_a": r.team_a, "key_b": r.team_b, "value": r.get("name"),
                     "entered_by": r.entered_by, "entered_at": _now().isoformat()})
    if rows:
        out = pd.DataFrame(rows)
        storage.write_parquet(config.TABLES / "ops" / "manual_lists.parquet", out)
        print(f"rivalries loaded: {len(out)}")
    # CFB injuries
    inj = pd.read_csv(MANUAL / "injuries_cfb.csv")
    inj = inj[inj.player_name.notna() & (inj.player_name.astype(str).str.strip() != "")]
    rows = []
    for _, r in inj.iterrows():
        if r.team_id not in known:
            vlog.reject("IDENTITY", f"injuries_cfb:{r.team_id}", "team_id", r.team_id, "known team_id"); continue
        if r.status not in ("OUT", "DOUBTFUL", "QUESTIONABLE", "PROBABLE", "IR"):
            vlog.reject("RANGE", f"injuries_cfb:{r.player_name}", "status", r.status, "OUT|DOUBTFUL|QUESTIONABLE|PROBABLE|IR"); continue
        rows.append({"injury_row_id": f"{r.team_id}_{str(r.player_name).replace(' ', '')}_{int(r.season)}W{int(r.week):02d}_{r.status}_{r.report_date}",
                     "league": "CFB", "season": int(r.season), "week": int(r.week), "game_id": None, "team_id": r.team_id,
                     "player_id": None, "player_name": r.player_name, "position": r.position, "depth_slot": None, "status": r.status,
                     "practice_status": None, "injury_desc": r.injury_desc if pd.notna(r.injury_desc) else None,
                     "report_date": r.report_date, "source": "manual", "entered_by": r.entered_by, "retrieved_at": _now().isoformat(),
                     "effective_at": pd.Timestamp(r.report_date).isoformat()})
    if rows:
        job.rows_written += storage.append_csv(ROSTER / "injuries" / "CFB" / f"{config.SEASON}.csv", pd.DataFrame(rows), ["injury_row_id"], on_duplicate="skip")
    # kickoff overrides
    ko = pd.read_csv(MANUAL / "kickoff_overrides.csv")
    if not ko.empty:
        ko["entered_at"] = _now().isoformat()
        storage.append_csv(config.TABLES / "ops" / "kickoff_overrides.csv", ko, ["game_id", "kickoff_utc"], on_duplicate="skip")


def weather(leagues: list[str], season: int, job: JobRun, vlog: ValidationLog):
    rm = RequestManager("open_meteo", job.job_run_id)
    venues = storage.read_table(REF / "venues.parquet")
    if venues.empty:
        job.message += " no venues table; run --what venues manual first;"; return
    vidx = venues.set_index("venue_id")
    now = pd.Timestamp(_now())
    horizon = now + pd.Timedelta(days=15)
    total = 0
    cache: dict[str, dict] = {}
    for league in leagues:
        games = storage.read_table(storage.games_path(league, season))
        if games.empty:
            continue
        up = games[(games.status == "SCHEDULED") & games.kickoff_utc.notna()].copy()
        up["k"] = pd.to_datetime(up.kickoff_utc, utc=True)
        up = up[(up.k >= now - pd.Timedelta(hours=4)) & (up.k <= horizon)]
        rows = []
        for _, g in up.iterrows():
            if pd.isna(g.venue_id) or g.venue_id not in vidx.index:
                vlog.warn("VENUE_MISSING", g.game_id, "venue_id", g.venue_id, "venues row"); continue
            v = vidx.loc[g.venue_id]
            roof = g.venue_roof if isinstance(g.get("venue_roof"), str) else v.roof
            if roof in open_meteo.INDOOR_ROOFS:
                rows.append(open_meteo.snapshot_row(g.game_id, g.k, roof, None, _now())); continue
            if pd.isna(v.latitude) or pd.isna(v.longitude):
                vlog.warn("VENUE_NO_COORDS", g.game_id, "latitude", None, "coordinates"); continue
            key = f"{round(float(v.latitude), 2)},{round(float(v.longitude), 2)}"
            if key not in cache:
                try:
                    cache[key] = rm.get(open_meteo.FORECAST, params={"latitude": v.latitude, "longitude": v.longitude, "hourly": open_meteo.HOURLY,
                                                                    "forecast_days": 16, **open_meteo.UNITS}).payload
                except (ProviderError, BudgetExceeded) as e:
                    vlog.warn("PROVIDER_FAIL", g.game_id, "open_meteo", str(e)[:80], "200"); cache[key] = None
            payload = cache[key]
            vals = open_meteo.pick_hour(payload, g.k) if payload else None
            rows.append(open_meteo.snapshot_row(g.game_id, g.k, roof, vals, _now()))
        if rows:
            df = pd.DataFrame(rows).merge(games[["game_id", "week"]], on="game_id")
            for wk, part in df.groupby("week"):
                total += storage.append_csv(CONTEXT / "weather_snapshots" / league / str(season) / f"W{int(wk):02d}.csv",
                                            part.drop(columns="week"), ["game_id", "retrieved_at"], on_duplicate="skip")
    job.rows_written += total
    job.api_calls += rm.calls_this_run
    print(f"weather: {total} snapshot rows, {rm.calls_this_run} Open-Meteo calls")


def weather_archive(leagues: list[str], season: int, job: JobRun, vlog: ValidationLog):
    """Historical game-day weather from the Open-Meteo archive, one call per unique (venue, date).
    Written to weather_snapshots as source=open_meteo_archive with is_actual=True (used by the backtest in place of a forecast)."""
    rm = RequestManager("open_meteo", job.job_run_id)
    venues = storage.read_table(REF / "venues.parquet")
    if venues.empty:
        job.message += " no venues;"; return
    vidx = venues.set_index("venue_id")
    total = 0
    cache: dict[tuple, dict | None] = {}
    for league in leagues:
        games = storage.read_table(storage.games_path(league, season))
        if games.empty:
            continue
        done = games[(games.status == "FINAL") & games.kickoff_utc.notna()].copy()
        done["k"] = pd.to_datetime(done.kickoff_utc, utc=True)
        existing = set()
        for p in (CONTEXT / "weather_snapshots" / league / str(season)).glob("W*.csv"):
            e = pd.read_csv(p); existing |= set(e[e.get("source", pd.Series(dtype=str)).eq("open_meteo_archive")].game_id) if "source" in e.columns else set()
        rows = []
        for _, g in done.iterrows():
            if g.game_id in existing or pd.isna(g.venue_id) or g.venue_id not in vidx.index:
                continue
            v = vidx.loc[g.venue_id]
            roof = g.venue_roof if isinstance(g.get("venue_roof"), str) else v.roof
            if roof in open_meteo.INDOOR_ROOFS:
                rows.append({**open_meteo.snapshot_row(g.game_id, g.k, roof, None, _now()), "source": "open_meteo_archive", "is_actual": True}); continue
            if pd.isna(v.latitude) or pd.isna(v.longitude):
                continue
            day = g.k.strftime("%Y-%m-%d")
            key = (round(float(v.latitude), 2), round(float(v.longitude), 2), day)
            if key not in cache:
                try:
                    cache[key] = rm.get(open_meteo.ARCHIVE, params={"latitude": v.latitude, "longitude": v.longitude, "hourly": open_meteo.HOURLY_ARCHIVE,
                                                                   "start_date": day, "end_date": day, **open_meteo.UNITS}).payload
                except (ProviderError, BudgetExceeded) as e:
                    vlog.warn("PROVIDER_FAIL", g.game_id, "open_meteo_archive", str(e)[:80], "200"); cache[key] = None
            vals = open_meteo.pick_hour(cache[key], g.k) if cache[key] else None
            rows.append({**open_meteo.snapshot_row(g.game_id, g.k, roof, vals, _now()), "source": "open_meteo_archive", "is_actual": True})
        if rows:
            df = pd.DataFrame(rows).merge(games[["game_id", "week"]], on="game_id")
            for wk, part in df.groupby("week"):
                total += storage.append_csv(CONTEXT / "weather_snapshots" / league / str(season) / f"W{int(wk):02d}.csv", part.drop(columns="week"), ["game_id", "retrieved_at"], on_duplicate="skip")
        print(f"{league} {season} weather archive: {len(rows)} rows, {rm.calls_this_run} calls so far")
    job.rows_written += total; job.api_calls += rm.calls_this_run


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--league", required=True, choices=["NFL", "CFB", "BOTH"])
    p.add_argument("--season", type=int, default=config.SEASON)
    p.add_argument("--what", nargs="+", default=["all"])
    p.add_argument("--trigger", default="manual")
    a = p.parse_args(argv)
    what = set(a.what)
    if "all" in what:
        what = {"players", "rosters", "injuries", "qbr", "rankings", "coaches", "venues", "fpi", "manual", "weather"}
    leagues = ["NFL", "CFB"] if a.league == "BOTH" else [a.league]
    with JobRun("CONTEXT", a.league, a.trigger) as job:
        vlog = ValidationLog(job.job_run_id, "context")
        if "manual" in what:
            load_manual(job, vlog)
        if "NFL" in leagues and what & {"players", "rosters", "injuries", "qbr", "coaches", "fpi"}:
            nfl(what, a.season, job)
        if "CFB" in leagues and what & {"rosters", "rankings", "coaches", "venues", "fpi"}:
            cfb(what, a.season, job, vlog)
        if "weather" in what:
            weather(leagues, a.season, job, vlog)
        if "weather_archive" in what:
            weather_archive(leagues, a.season, job, vlog)
        vlog.flush()
        if vlog.rejects:
            job.status = "PARTIAL"; job.message += f" {vlog.rejects} manual rows rejected;"


if __name__ == "__main__":
    main()
