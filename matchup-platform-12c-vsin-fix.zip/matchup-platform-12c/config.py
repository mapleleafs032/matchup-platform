"""
Centralized configuration. Nothing tunable lives anywhere else.
Secrets are NOT here: they come from environment variables set by GitHub Actions secrets.
"""
from __future__ import annotations
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
TABLES = DATA / "tables"
RAW = DATA / "raw"
SNAPSHOTS = DATA / "snapshots"
SITE_DIR = ROOT / "site"
SITE_JSON = SITE_DIR / "json"

SEASON = 2026
LEAGUES = ("CFB", "NFL")
BACKTEST_SEASONS = [2021, 2022, 2023, 2024, 2025]   # post-COVID only; 2020 and earlier are hard-rejected
MIN_ALLOWED_SEASON = 2021

# ---- Provider keys (env only) -------------------------------------------------
CFBD_API_KEY = os.environ.get("CFBD_API_KEY", "").strip()
ODDS_API_KEY = os.environ.get("ODDS_API_KEY", "").strip()
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "").strip()

# ---- Odds routing (decision #2: free now, paid is a config flip) --------------
ODDS_PLAN = os.environ.get("ODDS_PLAN", "free")          # "free" | "paid"
ODDS_ROUTING = {
    "free": {"NFL": "odds_api", "CFB": "cfbd"},
    "paid": {"NFL": "odds_api", "CFB": "odds_api"},
}[ODDS_PLAN]
ODDS_API_REGIONS = "us"
ODDS_API_MARKETS = "h2h,spreads,totals"                  # 3 credits per call on The Odds API
ODDS_API_SPORT_KEYS = {"NFL": "americanfootball_nfl", "CFB": "americanfootball_ncaaf"}
ODDS_BOOK_PRIORITY = ["consensus", "draftkings", "fanduel", "betmgm", "caesars", "espnbet", "bovada"]

# ---- API budgets (§50). Hard stops; jobs skip rather than exceed. ------------
API_BUDGET = {
    "cfbd":     {"monthly": 1000 if os.environ.get("CFBD_TIER", "free") == "free" else 5000, "daily_soft": 250},
    "odds_api": {"monthly": 500 if ODDS_PLAN == "free" else 20000, "daily_soft": 25},
    "open_meteo": {"monthly": 200000, "daily_soft": 5000},
    "nflverse": {"monthly": 10**9, "daily_soft": 10**9},
    "espn":     {"monthly": 5000, "daily_soft": 200},
    "vsin":     {"monthly": 3000, "daily_soft": 120},
    "splits_feed": {"monthly": 10000, "daily_soft": 500},
}
BUDGET_DEGRADE_AT_PCT_REMAINING = 0.15   # below this, odds cadence halves automatically

# ---- Refresh cadences (hours). Game-day cadences handled by Apps Script timer. -
CADENCE = {
    "schedules_hours": 24,
    "odds_midweek_per_day": {"free": {"NFL": 2, "CFB": 2}, "paid": {"NFL": 6, "CFB": 6}}[ODDS_PLAN],
    "odds_gameday_hours_before_kick": {"free": 6, "paid": 8}[ODDS_PLAN],
}

# ---- Validation ranges (§44). Fractions 0..1 unless noted. -------------------
VALIDATION_RANGES = {
    "spread_home": (-60.0, 60.0),
    "total": (20.0, 110.0),
    "moneyline": (-10000, 10000),
    "points": (0, 120),
    "week_cfb": (1, 16),      # CFBD week numbering starts at 1 (no week 0)
    "week_nfl": (1, 22),
}

# ---- Season / week conventions -------------------------------------------------
NFL_GAME_TYPE_TO_SEASON_TYPE = {"REG": "REG", "WC": "POST", "DIV": "POST", "CON": "POST", "SB": "POST"}
CFBD_SEASON_TYPE = {"regular": "REG", "postseason": "POST", "both": None}
NFL_TIMEZONE = "America/New_York"   # nflverse gametime is Eastern

# ---- Game-level metric definitions (pipeline/metrics_game.py) ------------------
EXPLOSIVE_RUSH_YDS = 10
EXPLOSIVE_PASS_YDS = 20
# Garbage time. CFB: CFBD's published rule (lead >= threshold by period). NFL: pre-snap vegas win prob band.
CFB_GARBAGE_LEAD_BY_PERIOD = {2: 38, 3: 28, 4: 22}
NFL_GARBAGE_WP_BAND = (0.05, 0.95)
# Which upstream stats files to pull per league (nflverse release assets)
NFLVERSE_ASSETS = {
    "pbp": "https://github.com/nflverse/nflverse-data/releases/download/pbp/play_by_play_{season}.parquet",
    "ftn": "https://github.com/nflverse/nflverse-data/releases/download/ftn_charting/ftn_charting_{season}.parquet",
    "pfr_pass": "https://github.com/nflverse/nflverse-data/releases/download/pfr_advstats/advstats_week_pass_{season}.parquet",
    "pfr_def": "https://github.com/nflverse/nflverse-data/releases/download/pfr_advstats/advstats_week_def_{season}.parquet",
}
CFBD_STATS_CALLS_PER_WEEK = 5     # games/teams, stats/game/advanced, plays, drives, games/players

# ---- Analytics layer (pipeline/asof.py, pipeline/ratings.py) -----------------------
USE_GARBAGE_FILTERED = True          # which team_game_advanced variant feeds the model
FCS_GAME_WEIGHT = 0.5                # CFB: weight of FBS-vs-FCS games in windows and ridge fits
NIGHT_GAME_LOCAL_HOUR = 18           # local kickoff hour >= this -> NIGHT window
RIDGE_LAMBDA = {"CFB": 3.0, "NFL": 2.0}          # opponent-adjustment shrinkage; tuned in Phase 8 backtest
RECENCY_WEIGHTS = {"SEASON": 0.5, "LAST5": 0.3, "LAST3": 0.2}   # starting framework (§17); tuned in Phase 8
PRIOR_WEIGHT_BY_WEEK = {             # weight on previous-season OPP_ADJ values (§40); tuned in Phase 8
    "CFB": {1: 0.85, 2: 0.75, 3: 0.65, 4: 0.50, 5: 0.40, 6: 0.30, 7: 0.20, 8: 0.10, "default": 0.05},
    "NFL": {1: 0.70, 2: 0.55, 3: 0.40, 4: 0.30, 5: 0.20, 6: 0.10, "default": 0.05},
}
LOW_SAMPLE_GAMES = {"CFB": 4, "NFL": 4}
QUALITY_TARGET_GAMES = {"CFB": 6, "NFL": 5}

# ---- Roster engine (pipeline/roster_engine.py) ----------------------------------------
RP_POSITION_WEIGHTS = {"passing": 0.30, "ol": 0.20, "receiving": 0.15, "rushing": 0.10, "defense": 0.25}   # §12; tuned in Phase 8
OL_STARTS_FULL = {"NFL": 85, "CFB": 5}        # NFL: 17 games x 5 starters; CFB proxy: 5 retained OL = "full"
DEF_PRODUCTION_WEIGHTS = {"tackles": 1.0, "tfl": 2.0, "sacks": 3.0, "ints": 3.0, "pbu": 2.0, "qb_hurries": 1.5, "pressures": 1.5, "ff": 2.0}
RECRUIT_CLASS_WEIGHTS = {0: 0.15, 1: 0.35, 2: 0.30, 3: 0.20}   # years ago -> weight (current class matters least in-season)
CONTINUITY_WEIGHTS = {"CFB": {"rp_total": 0.45, "qb": 0.25, "hc": 0.15, "portal_churn": 0.15},
                      "NFL": {"rp_total": 0.50, "qb": 0.30, "hc": 0.20}}
PORTAL_CHURN_FULL = 25                         # incoming transfers at which churn penalty saturates
CFBD_ROSTER_CALLS_PER_SEASON = 8

# ---- Matchup engine (pipeline/matchup_engine.py). Weights = points per league-SD of edge_raw. PRIORS; fit in Phase 8. ----
MATCHUP_MODEL_VERSION = "MATCHUP_v0.7_prelim"
_W_NFL = {"OVERALL_OFF": 1.5, "OVERALL_DEF": 1.5, "PASS_OFF": 1.0, "PASS_DEF": 1.0, "RUSH_OFF": 0.5, "RUSH_DEF": 0.5, "QB": 1.5,
          "OFFENSIVE_LINE": 0.6, "DEFENSIVE_FRONT": 0.6, "EXPLOSIVE": 0.6, "SUCCESS": 0.5, "THIRD_DOWN": 0.3, "RED_ZONE": 0.3,
          "TURNOVER": 0.3, "SPECIAL_TEAMS": 0.3, "COACHING": 0.5, "TALENT": 0.0, "RETURNING_PROD": 0.5, "RECENT_FORM": 0.4,
          "SOS": 0.0, "HOME_FIELD": 1.0, "STYLE_FIT": 0.5, "INJURY": 1.0, "WEATHER": 0.3, "REST": 0.6}
MATCHUP_WEIGHTS_INIT = {"NFL": _W_NFL, "CFB": {**{k: v * 1.6 for k, v in _W_NFL.items()}, "TALENT": 1.0, "RETURNING_PROD": 0.8, "COACHING": 0.6, "HOME_FIELD": 1.0}}
HFA_DEFAULT_POINTS = {"NFL": 1.5, "CFB": 2.5}     # used only when no fitted ratings exist for the week
INJURY_POSITION_WEIGHTS = {"QB": 3.0, "OL": 0.6, "RB": 0.5, "WR": 0.6, "TE": 0.4, "EDGE": 0.7, "DL": 0.5, "LB": 0.4, "CB": 0.6, "S": 0.4, "K": 0.3, "P": 0.1, "LS": 0.05, "UNK": 0.2}
INJURY_SD_POINTS = 1.5            # injury burden units per league-SD (QB out alone = 2 SD)
TURNOVER_REGRESSION = 0.4         # turnover margin is mostly noise; shrink toward zero
WIND_PASS_THRESHOLD_MPH = 12
QB_MIN_CAREER_ATT = 80         # attempts in our 2021+ tables before career evidence is used for the QB index

# ---- Prediction model (pipeline/model.py, jobs/backtest.py, jobs/predict.py) ----------------
LEAGUE_AVG_TOTAL = {"NFL": 44.0, "CFB": 54.0}
TOTAL_FLOOR = 20.0
ATS_EDGE_THRESHOLD = {"NFL": 2.0, "CFB": 3.0}      # points of model-vs-market disagreement to count as an "edge" pick
CLOSING_BOOK_PRIORITY = ["nflverse_close", "consensus", "draftkings", "fanduel", "bovada", "betmgm", "espnbet"]
HFA_SHRINK_GAMES = {"NFL": 120, "CFB": 400}         # games of fit needed before the fitted HFA fully replaces the league prior

# ---- Market engine (pipeline/market_engine.py) -----------------------------------------
STEAM_WINDOW_HOURS = 3
MIN_PROJ_SIDE = {"NFL": 7.0, "CFB": 10.0}   # projected total is raised so neither team is projected below this (blowouts run up the total)

# ---- AI analysis layer (pipeline/ai_agent.py, jobs/build_ai.py) -------------------------------
AI_MODEL_CANDIDATES = ["claude-sonnet-5", "claude-sonnet-4-6", "claude-haiku-4-5-20251001"]   # first that the account can use is kept
AI_MAX_GAMES_PER_RUN = 120          # cost guard per job run
AI_PROMPT_VERSION = "ai_v1.0"

# ---- Betting splits (ticket % / money %) ------------------------------------------------
# No free licensed feed exists. Input is either a manual paste (data/manual/splits_paste/) or a feed you license.
SPLITS_FEED = {"enabled": False, "provider": None, "base_url": None}
SPLITS_API_KEY = os.environ.get("SPLITS_API_KEY", "").strip()
SPLITS_BOOK_DEFAULT = "draftkings"
# VSiN publishes DraftKings ticket/handle splits on a public page. Polite cadence, identifying User-Agent,
# attribution shown in the app. Set enabled=False to stop collecting immediately.
VSIN = {"enabled": True, "attribution": "Betting splits: DraftKings action via VSiN (data.vsin.com)"}
SPLITS_PERIODS = ("FULL", "1H")
# Divergence: ticket share minus money share, in percentage points, at which the two disagree enough to note.
SPLITS_DIVERGENCE_PTS = 12
# Reverse line movement: the line moved toward the side with the MINORITY of tickets by at least this much.
RLM_MIN_MOVE = 0.5
RLM_MIN_TICKET_PCT = 0.60

# ---- Storage --------------------------------------------------------------------
APPEND_ONLY_PATHS = [   # CI immutability check (Phase 3 §3) — relative to repo root
    "data/tables/market/snapshots",
    "data/tables/market/splits",
    "data/tables/model/predictions",
    "data/tables/model/pregame_final_flags.csv",
    "data/tables/model/ai_analyses",
    "data/tables/model/ai_analyses_index.csv",
    "data/tables/model/pregame_snapshots_index.csv",
    "data/tables/model/model_evaluation",
    "data/tables/results",
    "data/tables/roster/injuries",
    "data/tables/context/weather_snapshots",
    "data/tables/ops/job_log.csv",
    "data/tables/ops/validation_log.csv",
    "data/tables/ops/raw_responses.csv",
    "data/snapshots",
]

# Raw payload archiving: keyed/quota APIs are archived (small JSON, needed for rebuilds and disputes).
# nflverse bulk files are NOT archived (1 MB+ per pull, publicly versioned upstream); the index row still records the sha.
RAW_ARCHIVE_PROVIDERS = {"cfbd", "odds_api", "espn", "open_meteo"}

PIPELINE_VERSION = "ingest_v0.1"
